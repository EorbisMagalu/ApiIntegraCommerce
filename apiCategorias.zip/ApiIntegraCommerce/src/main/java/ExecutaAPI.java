
import com.integracommerce.ctrl.CategoriasCtrl;
import com.integracommerce.entidade.categoria.Categoria;
import java.util.ArrayList;
import java.util.List;


public class ExecutaAPI {

    public static void main(String[] args) {
        
        CategoriasCtrl categoriasCtrl = new CategoriasCtrl();
//        System.out.println(categoriasCtrl.sendGet(null, "001").getName());
//        Categoria categoria = new Categoria();
//        List<Categoria> categorias = new ArrayList<>();
//        categoria.setId("001");
//        categoria.setName("Teste 001");
//        categoria.setParentId("");
//        categorias.add(categoria);
//        
//        categoriasCtrl.sendPost(categorias, null);
//        categoriasCtrl.sendGetAll(null).getCategorias().forEach(e->{System.out.println(e.getName());});
        
    }

}