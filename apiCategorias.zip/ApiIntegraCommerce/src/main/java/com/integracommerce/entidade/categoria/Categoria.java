package com.integracommerce.entidade.categoria;


public class Categoria {

    public String Id;
    public String Name;
    public String ParentId;

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getParentId() {
        return ParentId;
    }

    public void setParentId(String ParentId) {
        this.ParentId = ParentId;
    }
}
    

//    public List<Categoria> getCategorias() {
//        return categorias;
//    }
//
//    public void setCategorias(List<Categoria> categorias) {
//        this.categorias = categorias;
//    }

//    public void addCategorias(Categoria categoria) {
//        this.categorias.add(categoria);
//    }

//    @JsonBackReference
//    private List<Categoria> categorias;

//    public Categoria() {
//        if(this.categorias == null) {
//            this.categorias = new ArrayList<>();
//        }
//    }