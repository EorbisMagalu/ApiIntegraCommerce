package com.integracommerce.entidade.categoria;

import java.util.List;
import org.codehaus.jackson.annotate.JsonIgnore;

public class Categorias {

    public int Page;
    public int PerPage;
    public int Total;
    public List<Categoria> Categories;

    @JsonIgnore
    public Object CategoriesMarketplace;

    public int getPage() {
        return Page;
    }

    public void setPage(int Page) {
        this.Page = Page;
    }

    public int getPerPage() {
        return PerPage;
    }

    public void setPerPage(int PerPage) {
        this.PerPage = PerPage;
    }

    public int getTotal() {
        return Total;
    }

    public void setTotal(int Total) {
        this.Total = Total;
    }

    public List<Categoria> getCategorias() {
        return Categories;
    }

    public void setCategorias(List<Categoria> Categories) {
        this.Categories = Categories;
    }

    public Object getCategoriesMarketplace() {
        return CategoriesMarketplace;
    }

    public void setCategoriesMarketplace(Object CategoriesMarketplace) {
        this.CategoriesMarketplace = CategoriesMarketplace;
    }

}