package com.integracommerce.ctrl;

import com.integracommerce.entidade.categoria.Categoria;
import com.integracommerce.entidade.categoria.Categorias;
import java.io.IOException;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;

public class CategoriasCtrl {

    public void sendPost(List<Categoria> categorias, String url) {
        if (StringUtils.isBlank(url)) {
            url = "https://api.integracommerce.com.br/api/Category";
        }
        HttpPost post = new HttpPost(url);
        post.setHeader("cache-control", "no-cache");
        post.setHeader("Content-Type", "application/json");
        post.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");
        try {
            String strCategoria = new ObjectMapper().writeValueAsString(categorias);
            StringEntity stringEntity = new StringEntity(strCategoria, ContentType.APPLICATION_JSON);
            post.setEntity(stringEntity);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(post);
            response.getStatusLine().getStatusCode();
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode >= 400) {
                throw new RuntimeException("Erro ao realizar requisição!");
            }
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

    }

    public Categorias sendGetAll(String url,String strPagePerPage) {
        try {
            if(StringUtils.isBlank(strPagePerPage)) {
                strPagePerPage = "level=0&page=1&perPage=100";
            }
            if(StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Category?";
            }
            HttpGet get = new HttpGet(url+strPagePerPage);
            get.setHeader("cache-control", "no-cache");
            get.setHeader("Content-Type", "application/json");
            get.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(get);
            ObjectMapper objectMapper = new ObjectMapper();
            String strResponse = EntityUtils.toString(response.getEntity());
            Categorias categorias = objectMapper.readValue(strResponse, Categorias.class);
            return categorias;
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
    

    public Categoria sendGet(String url,String id) {
        try {
            if(StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Category/";
            }
            HttpGet get = new HttpGet(url + id);
            get.setHeader("cache-control", "no-cache");
            get.setHeader("Content-Type", "application/json");
            get.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(get);
            ObjectMapper objectMapper = new ObjectMapper();
            String strResponse = EntityUtils.toString(response.getEntity());
            Categoria categoria = objectMapper.readValue(strResponse, Categoria.class);
            return categoria;
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

}
