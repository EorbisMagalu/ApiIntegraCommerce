
import com.integracommerce.ctrl.MarketplaceCtrl;
import com.integracommerce.entidade.marketplace.Filtros;


public class ExecutaAPI {
    
    public static void main(String[] args) {
        
        MarketplaceCtrl ctrl = new MarketplaceCtrl();
        ctrl.requestGetAll(null, new Filtros("magazineluiza", 0, 1, 10)).getMarketplaceStructures().forEach(e->{System.out.println(e.getName());});
    }
}

//ProdutosCtrl ctrl = new ProdutosCtrl();
//        
//Produto produto = new Produto();
//produto.setIdProduct("7753");
//produto.setCode("41");
//produto.setName("Linguagem Python");
//produto.setBrand("Holanda");
//produto.setNbmOrigin("258");
//produto.setNbmNumber("951");
//produto.setWarrantyTime("12");
//produto.setActive(true);
//
//
//List<Categoria> categorias = new ArrayList<>();
//categorias.add(new Categoria("2", "Tecnologia", "5"));
//produto.setCategories(categorias);
//
//List<MarketplaceStructures> structureses = new ArrayList<>();
//structureses.add(new MarketplaceStructures("mgl-RCNM","No Magalu","mgl-RC"));
//produto.setMarketplaceStructures(structureses);
//
//ctrl.requestPost(null,produto);