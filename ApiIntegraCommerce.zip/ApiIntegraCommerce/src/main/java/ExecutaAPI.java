
import com.integracommerce.utilfreemarker.JsonUtil;
import com.integracommerce.utilfreemarker.ServiceUtil;
import com.integracommerce.utilfreemarker.TemplateManager;
import freemarker.ext.beans.BeansWrapperBuilder;
import freemarker.template.Configuration;
import freemarker.template.TemplateHashModel;
import freemarker.template.TemplateModelException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ExecutaAPI {

    public static void main(String[] args) throws IOException, TemplateModelException {

        Map<String, Object> data = new HashMap<>();
        TemplateHashModel staticModels = new BeansWrapperBuilder(Configuration.VERSION_2_3_31).build().getStaticModels();
        
        data.put("HttpGet", staticModels.get(ServiceUtil.class.getName()));
        data.put("JsonUtil", staticModels.get(JsonUtil.class.getName()));
        
        TemplateManager templateManager = new TemplateManager();
        String retorno = templateManager.processTemplate("templateRequest02", data);
        
        System.out.println(retorno);
        
    }
}













//HttpPost post = new HttpPost("https://api.mercadolibre.com/shipments/40663163620/invoice_data/&siteId=MLB");
//post.setHeader("Authorization", "Bearer APP_USR-6080348676133328-062513-f1227dd7bcdca7b26fb3e8a93a50b231-769168490");
//post.setHeader("Content-Type", "application/xml");
//post.setHeader("x-format-new","true");
//String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<nfeProc versao=\"4.00\" xmlns=\"http://www.portalfiscal.inf.br/nfe\">\n</nfeProc>";
//StringEntity stringEntity = new StringEntity(data, ContentType.APPLICATION_XML);
//post.setEntity(stringEntity);
//HttpClient httpClient = HttpClients.createDefault();
//HttpResponse response = httpClient.execute(post);
//int statusCode = response.getStatusLine().getStatusCode();
//String strResponse = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
//if (statusCode >= 400) {
//    throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + strResponse);
//}
//String originalInput = "metaprime.api.sandbox:pI5@Z5Ot;0IpkWwGQtmq";
//String encodedString = Base64.getEncoder().encodeToString(originalInput.getBytes());
//bWV0YXByaW1lLmFwaS5zYW5kYm94OnBJNUBaNU90OzBJcGtXd0dRdG1x
