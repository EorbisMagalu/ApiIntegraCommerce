
import com.integracommerce.utilfreemarker.TemplateManager;
import freemarker.ext.beans.BeansWrapperBuilder;
import freemarker.template.Configuration;
import freemarker.template.TemplateHashModel;
import freemarker.template.TemplateModelException;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

public class ExecutaAPI {

    public static void main(String[] args) throws IOException, TemplateModelException {        

        //String jsonAnuncio = JsonUtil.jsonToMap(anuncio);
        TemplateHashModel staticModels = new BeansWrapperBuilder(Configuration.VERSION_2_3_31).build().getStaticModels();
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("Anuncio", "object");
        data.put("ExecutaAPI", staticModels.get(ExecutaAPI.class.getName()));
        TemplateManager manager = new TemplateManager();
        String srtTemplate = manager.processTemplate("templatePublicarAnuncio", data);
        System.out.println(srtTemplate);
        
        
    }

    public static String teste(final String strJson) {
        System.out.println(strJson);
        return strJson;
    }

}