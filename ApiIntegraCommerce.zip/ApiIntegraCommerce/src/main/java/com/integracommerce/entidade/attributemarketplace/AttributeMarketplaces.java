
package com.integracommerce.entidade.attributemarketplace;

import com.integracommerce.entidade.atributos.Attribute;
import java.util.List;

public class AttributeMarketplaces {
    
    public List<Attribute> AttributeMarketplaces;
    public MetaData MetaData;

    public List<Attribute> getAttributeMarketplaces() {
        return AttributeMarketplaces;
    }

    public void setAttributeMarketplaces(List<Attribute> AttributeMarketplaces) {
        this.AttributeMarketplaces = AttributeMarketplaces;
    }

    public MetaData getMetaData() {
        return MetaData;
    }

    public void setMetaData(MetaData MetaData) {
        this.MetaData = MetaData;
    }

}
