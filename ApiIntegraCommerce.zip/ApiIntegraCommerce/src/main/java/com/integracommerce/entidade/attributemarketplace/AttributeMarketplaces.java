
package com.integracommerce.entidade.attributemarketplace;

import com.integracommerce.entidade.atributos.Attribute;
import java.util.List;
import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class AttributeMarketplaces {
    
    private List<Attribute> AttributeMarketplaces;
    private MetaData MetaData;

    public List<Attribute> getAttributeMarketplaces() {
        return AttributeMarketplaces;
    }

    public void setAttributeMarketplaces(List<Attribute> AttributeMarketplaces) {
        this.AttributeMarketplaces = AttributeMarketplaces;
    }

    public MetaData getMetaData() {
        return MetaData;
    }

    public void setMetaData(MetaData MetaData) {
        this.MetaData = MetaData;
    }

}
