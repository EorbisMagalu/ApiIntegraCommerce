package com.integracommerce.entidade.endpointlimit;

import java.util.List;
import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class EndPointLimit {

    private String Name;
    private int RequestsByMinute;
    private int RequestsByHour;
    private List<EndPointLimit> endPointLimits;
    
    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getRequestsByMinute() {
        return RequestsByMinute;
    }

    public void setRequestsByMinute(int RequestsByMinute) {
        this.RequestsByMinute = RequestsByMinute;
    }

    public int getRequestsByHour() {
        return RequestsByHour;
    }

    public void setRequestsByHour(int RequestsByHour) {
        this.RequestsByHour = RequestsByHour;
    }

    public List<EndPointLimit> getEndPointLimits() {
        return endPointLimits;
    }

    public void setEndPointLimits(List<EndPointLimit> endPointLimits) {
        this.endPointLimits = endPointLimits;
    }
    
    

}
