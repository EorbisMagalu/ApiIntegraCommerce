
package com.integracommerce.entidade.produto;

import com.integracommerce.entidade.atributos.Attribute;
import com.integracommerce.entidade.categoria.Categoria;
import com.integracommerce.entidade.marketplace.MarketplaceStructures;
import java.util.List;
import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class Produto {
    
    private String IdProduct; //Id do produto(Obrigatório)
    private String Name; //Nome do produto (Obrigatório)
    private String Code; //Código do produto no ERP, pode ser igual ao
    private String Brand; //Marca (Obrigatório)
    private String NbmOrigin; //NBM de origem, 0 para nacional, 1 para 
    private String NbmNumber; //NbmNumber é o mesmo que o NCM do produto
    private String WarrantyTime; //garantia em meses
    private boolean Active; //Status do produto (Obrigatório)
    private List<Categoria> Categories; //quantidade máxima de categorias: 4. Caso ultrapasse o limite, serão considerados apenas os 4 primeiros
    private List<Attribute> Attributes; //Não é necessário preencher esse array com atributos;
    private List<MarketplaceStructures> MarketplaceStructures;

    public String getIdProduct() {
        return IdProduct;
    }

    public void setIdProduct(String IdProduct) {
        this.IdProduct = IdProduct;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getCode() {
        return Code;
    }

    public void setCode(String Code) {
        this.Code = Code;
    }

    public String getBrand() {
        return Brand;
    }

    public void setBrand(String Brand) {
        this.Brand = Brand;
    }

    public String getNbmOrigin() {
        return NbmOrigin;
    }

    public void setNbmOrigin(String NbmOrigin) {
        this.NbmOrigin = NbmOrigin;
    }

    public String getNbmNumber() {
        return NbmNumber;
    }

    public void setNbmNumber(String NbmNumber) {
        this.NbmNumber = NbmNumber;
    }

    public String getWarrantyTime() {
        return WarrantyTime;
    }

    public void setWarrantyTime(String WarrantyTime) {
        this.WarrantyTime = WarrantyTime;
    }

    public boolean getActive() {
        return Active;
    }

    public void setActive(boolean Active) {
        this.Active = Active;
    }

    public List<Categoria> getCategories() {
        return Categories;
    }

    public void setCategories(List<Categoria> Categories) {
        this.Categories = Categories;
    }

    public List<Attribute> getAttributes() {
        return Attributes;
    }

    public void setAttributes(List<Attribute> Attributes) {
        this.Attributes = Attributes;
    }

    public List<MarketplaceStructures> getMarketplaceStructures() {
        return MarketplaceStructures;
    }

    public void setMarketplaceStructures(List<MarketplaceStructures> MarketplaceStructures) {
        this.MarketplaceStructures = MarketplaceStructures;
    }

    

}
