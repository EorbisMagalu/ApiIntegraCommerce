
package com.integracommerce.entidade.categoria;

import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class CategoryMarketplaceList {
    
    private Integer CategoryId;
    private String CategoryName;
    private Integer SubCategoryId;
    private String SubCategoryName;
    private Integer FamilyId;
    private String FamilyName;
    private Integer SubFamilyId;
    private String SubFamilyName;

    public Integer getCategoryId() {
        return CategoryId;
    }

    public void setCategoryId(Integer CategoryId) {
        this.CategoryId = CategoryId;
    }

    public String getCategoryName() {
        return CategoryName;
    }

    public void setCategoryName(String CategoryName) {
        this.CategoryName = CategoryName;
    }

    public Integer getSubCategoryId() {
        return SubCategoryId;
    }

    public void setSubCategoryId(Integer SubCategoryId) {
        this.SubCategoryId = SubCategoryId;
    }

    public String getSubCategoryName() {
        return SubCategoryName;
    }

    public void setSubCategoryName(String SubCategoryName) {
        this.SubCategoryName = SubCategoryName;
    }

    public Integer getFamilyId() {
        return FamilyId;
    }

    public void setFamilyId(Integer FamilyId) {
        this.FamilyId = FamilyId;
    }

    public String getFamilyName() {
        return FamilyName;
    }

    public void setFamilyName(String FamilyName) {
        this.FamilyName = FamilyName;
    }

    public Integer getSubFamilyId() {
        return SubFamilyId;
    }

    public void setSubFamilyId(Integer SubFamilyId) {
        this.SubFamilyId = SubFamilyId;
    }

    public String getSubFamilyName() {
        return SubFamilyName;
    }

    public void setSubFamilyName(String SubFamilyName) {
        this.SubFamilyName = SubFamilyName;
    }
    
    
    
}
