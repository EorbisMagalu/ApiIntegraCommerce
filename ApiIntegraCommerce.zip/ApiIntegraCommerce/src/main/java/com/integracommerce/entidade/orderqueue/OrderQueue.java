
package com.integracommerce.entidade.orderqueue;

import java.util.List;
import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class OrderQueue {
    
    private String Id;
    private String IdOrder;
    private String IdOrderMarketplace;
    private String InsertedDate;
    private String OrderStatus;
    private int total;
    private List<OrderQueue> OrderQueues;

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public String getIdOrder() {
        return IdOrder;
    }

    public void setIdOrder(String IdOrder) {
        this.IdOrder = IdOrder;
    }

    public String getIdOrderMarketplace() {
        return IdOrderMarketplace;
    }

    public void setIdOrderMarketplace(String IdOrderMarketplace) {
        this.IdOrderMarketplace = IdOrderMarketplace;
    }

    public String getInsertedDate() {
        return InsertedDate;
    }

    public void setInsertedDate(String InsertedDate) {
        this.InsertedDate = InsertedDate;
    }

    public String getOrderStatus() {
        return OrderStatus;
    }

    public void setOrderStatus(String OrderStatus) {
        this.OrderStatus = OrderStatus;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public List<OrderQueue> getOrderQueues() {
        return OrderQueues;
    }

    public void setOrderQueues(List<OrderQueue> OrderQueues) {
        this.OrderQueues = OrderQueues;
    }    
}
