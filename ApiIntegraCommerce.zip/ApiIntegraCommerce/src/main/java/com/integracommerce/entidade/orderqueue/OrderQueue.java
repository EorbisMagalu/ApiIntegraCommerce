
package com.integracommerce.entidade.orderqueue;

import java.util.List;

public class OrderQueue {
    
    public String Id;
    public String IdOrder;
    public String IdOrderMarketplace;
    public String InsertedDate;
    public String OrderStatus;
    public int total;
    public List<OrderQueue> OrderQueues;

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public String getIdOrder() {
        return IdOrder;
    }

    public void setIdOrder(String IdOrder) {
        this.IdOrder = IdOrder;
    }

    public String getIdOrderMarketplace() {
        return IdOrderMarketplace;
    }

    public void setIdOrderMarketplace(String IdOrderMarketplace) {
        this.IdOrderMarketplace = IdOrderMarketplace;
    }

    public String getInsertedDate() {
        return InsertedDate;
    }

    public void setInsertedDate(String InsertedDate) {
        this.InsertedDate = InsertedDate;
    }

    public String getOrderStatus() {
        return OrderStatus;
    }

    public void setOrderStatus(String OrderStatus) {
        this.OrderStatus = OrderStatus;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public List<OrderQueue> getOrderQueues() {
        return OrderQueues;
    }

    public void setOrderQueues(List<OrderQueue> OrderQueues) {
        this.OrderQueues = OrderQueues;
    }    
}
