package com.integracommerce.entidade.categoria;

import java.util.ArrayList;
import java.util.List;
import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class Categoria {

    private String Id;
    private String Name;
    private String ParentId;

    public Categoria() {
    }

    public Categoria(String Id, String Name, String ParentId) {
        this.Id = Id;
        this.Name = Name;
        this.ParentId = ParentId;
    }

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getParentId() {
        return ParentId;
    }

    public void setParentId(String ParentId) {
        this.ParentId = ParentId;
    }
    
    public List novaInstancia() {
        return new ArrayList<>();
    }
}
