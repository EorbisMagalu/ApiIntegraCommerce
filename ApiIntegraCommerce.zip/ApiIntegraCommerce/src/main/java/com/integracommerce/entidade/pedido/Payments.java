
package com.integracommerce.entidade.pedido;

import java.math.BigDecimal;
import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class Payments {
    
    private TipoPagamento Name;
    private Integer Installments;
    private BigDecimal Amount;

    public Payments() {
    }

    public Payments(TipoPagamento Name, Integer Installments, BigDecimal Amount) {
        this.Name = Name;
        this.Installments = Installments;
        this.Amount = Amount;
    }

    public TipoPagamento getName() {
        return Name;
    }

    public void setName(TipoPagamento Name) {
        this.Name = Name;
    }

    public Integer getInstallments() {
        return Installments;
    }

    public void setInstallments(Integer Installments) {
        this.Installments = Installments;
    }

    public BigDecimal getAmount() {
        return Amount;
    }

    public void setAmount(BigDecimal Amount) {
        this.Amount = Amount;
    }

}
