
package com.integracommerce.entidade.pedido;

import java.math.BigDecimal;
import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class Payments {
    
    private String Name;
    private Integer Installments;
    private BigDecimal Amount;

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public Integer getInstallments() {
        return Installments;
    }

    public void setInstallments(Integer Installments) {
        this.Installments = Installments;
    }

    public BigDecimal getAmount() {
        return Amount;
    }

    public void setAmount(BigDecimal Amount) {
        this.Amount = Amount;
    }

}
