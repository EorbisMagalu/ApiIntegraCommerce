
package com.integracommerce.entidade.marketplace;

//import org.codehaus.jackson.annotate.JsonAutoDetect;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

//@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class Filtros {
    
    private String marketplaceName;
    private Integer parentId;
    private Integer page;
    private Integer perPage;

    public Filtros() {
    }

    public Filtros(String marketplaceName, Integer parentId, Integer page, Integer perPage) {
        this.marketplaceName = marketplaceName;
        this.parentId = parentId;
        this.page = page;
        this.perPage = perPage;
    }

    public Map<String, Object> params() {
        
        Map<String,Object> par = new HashMap<>();

        if(!StringUtils.isBlank(this.getMarketplaceName())) {
            par.put("marketplaceName", this.getMarketplaceName());
        }
        
        if(this.getParentId() != null && this.getParentId() > -1) {
            par.put("parentId", this.getParentId());
        }
        
        if(this.getPage() != null && this.getPage() >= 0) {
            par.put("page", this.getPage());
        }
        
        if(this.getPerPage() != null && !(this.getPerPage() < 0)) {
            par.put("perPage", this.getPerPage());
        }

        return par;
    }
    
    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getPerPage() {
        return perPage;
    }

    public void setPerPage(Integer perPage) {
        this.perPage = perPage;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public String getMarketplaceName() {
        return marketplaceName;
    }

    public void setMarketplaceName(String marketplaceName) {
        this.marketplaceName = marketplaceName;
    }
    
    
}
