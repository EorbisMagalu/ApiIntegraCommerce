package com.integracommerce.entidade.pedido;

import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

public class Filtros {

    public String StartDate;
    public String EndDate;
    public Integer Page;
    public Integer PerPage;
    public StatusPedido status;

    public Filtros() {
    }

    public Filtros(Integer Page, Integer PerPage,String StartDate, String EndDate,StatusPedido status) {
        this.StartDate = StartDate;
        this.EndDate = EndDate;
        this.Page = Page;
        this.PerPage = PerPage;
        this.status = status;
    }

    public Filtros(Integer Page, Integer PerPage,String StartDate, String EndDate) {
        this.StartDate = StartDate;
        this.EndDate = EndDate;
        this.Page = Page;
        this.PerPage = PerPage;
    }
    
    public Filtros(Integer Page, Integer PerPage,StatusPedido status) {
        this.status = status;
        this.Page = Page;
        this.PerPage = PerPage;
    }

    public Filtros(Integer Page, Integer PerPage) {
        this.Page = Page;
        this.PerPage = PerPage;
    }
    
    public String getStartDate() {
        return StartDate;
    }

    public void setStartDate(String StartDate) {
        this.StartDate = StartDate;
    }

    public String getEndDate() {
        return EndDate;
    }

    public void setEndDate(String EndDate) {
        this.EndDate = EndDate;
    }

    public Integer getPage() {
        return Page;
    }

    public void setPage(Integer Page) {
        this.Page = Page;
    }

    public Integer getPerPage() {
        return PerPage;
    }

    public void setPerPage(Integer PerPage) {
        this.PerPage = PerPage;
    }

    public StatusPedido getStatus() {
        return status;
    }

    public void setStatus(StatusPedido status) {
        this.status = status;
    }

    public Map<String, Object> params() {

        Map<String, Object> par = new HashMap<>();

        if (!StringUtils.isBlank(this.getStartDate())) {
            par.put("startDate", this.getStartDate());
        }
        if (!StringUtils.isBlank(this.getEndDate())) {
            par.put("endDate", this.getEndDate());
        }
        if (this.getPage() > 0) {
            par.put("page", this.getPage());
        }
        if (this.getPerPage() > 0) {
            par.put("perPage", this.getPerPage());
        }
        if (this.status != null) {
            par.put("status", this.status.name());
        }
        return par;
    }

}
