package com.integracommerce.entidade.atributos;

import java.util.List;

public class Attributes {

    public int Page;
    public int PerPage;
    public int Total;
    public List<Attribute> Attributes;

    public int getPage() {
        return Page;
    }

    public void setPage(int Page) {
        this.Page = Page;
    }

    public int getPerPage() {
        return PerPage;
    }

    public void setPerPage(int PerPage) {
        this.PerPage = PerPage;
    }

    public int getTotal() {
        return Total;
    }

    public void setTotal(int Total) {
        this.Total = Total;
    }

    public List<Attribute> getAttributes() {
        return Attributes;
    }

    public void setAttributes(List<Attribute> Attributes) {
        this.Attributes = Attributes;
    }

}
