
package com.integracommerce.entidade.orderpackage;

public class OrderPackage {
    
    public String IdOrderPackage;
    public String IdOrder;
    public String OrderPackageStatus;
    public String DeliveryPrice;
    public int DeliveryDays;
    public String IdShipping;
    public String ShippingName;
    public String ShippingType;
    public String ShippedTrackingUrl;
    public String ShippedTrackingProtocol;
    public String InvoicedNumber;
    public String InvoicedLine;
    public String InvoicedIssueDate;
    public String InvoicedKey;
    public String UpdatedMarketplaceStatus;

    public String getIdOrderPackage() {
        return IdOrderPackage;
    }

    public void setIdOrderPackage(String IdOrderPackage) {
        this.IdOrderPackage = IdOrderPackage;
    }

    public String getIdOrder() {
        return IdOrder;
    }

    public void setIdOrder(String IdOrder) {
        this.IdOrder = IdOrder;
    }

    public String getOrderPackageStatus() {
        return OrderPackageStatus;
    }

    public void setOrderPackageStatus(String OrderPackageStatus) {
        this.OrderPackageStatus = OrderPackageStatus;
    }

    public String getDeliveryPrice() {
        return DeliveryPrice;
    }

    public void setDeliveryPrice(String DeliveryPrice) {
        this.DeliveryPrice = DeliveryPrice;
    }

    public int getDeliveryDays() {
        return DeliveryDays;
    }

    public void setDeliveryDays(int DeliveryDays) {
        this.DeliveryDays = DeliveryDays;
    }

    public String getIdShipping() {
        return IdShipping;
    }

    public void setIdShipping(String IdShipping) {
        this.IdShipping = IdShipping;
    }

    public String getShippingName() {
        return ShippingName;
    }

    public void setShippingName(String ShippingName) {
        this.ShippingName = ShippingName;
    }

    public String getShippingType() {
        return ShippingType;
    }

    public void setShippingType(String ShippingType) {
        this.ShippingType = ShippingType;
    }

    public String getShippedTrackingUrl() {
        return ShippedTrackingUrl;
    }

    public void setShippedTrackingUrl(String ShippedTrackingUrl) {
        this.ShippedTrackingUrl = ShippedTrackingUrl;
    }

    public String getShippedTrackingProtocol() {
        return ShippedTrackingProtocol;
    }

    public void setShippedTrackingProtocol(String ShippedTrackingProtocol) {
        this.ShippedTrackingProtocol = ShippedTrackingProtocol;
    }

    public String getInvoicedNumber() {
        return InvoicedNumber;
    }

    public void setInvoicedNumber(String InvoicedNumber) {
        this.InvoicedNumber = InvoicedNumber;
    }

    public String getInvoicedLine() {
        return InvoicedLine;
    }

    public void setInvoicedLine(String InvoicedLine) {
        this.InvoicedLine = InvoicedLine;
    }

    public String getInvoicedIssueDate() {
        return InvoicedIssueDate;
    }

    public void setInvoicedIssueDate(String InvoicedIssueDate) {
        this.InvoicedIssueDate = InvoicedIssueDate;
    }

    public String getInvoicedKey() {
        return InvoicedKey;
    }

    public void setInvoicedKey(String InvoicedKey) {
        this.InvoicedKey = InvoicedKey;
    }

    public String getUpdatedMarketplaceStatus() {
        return UpdatedMarketplaceStatus;
    }

    public void setUpdatedMarketplaceStatus(String UpdatedMarketplaceStatus) {
        this.UpdatedMarketplaceStatus = UpdatedMarketplaceStatus;
    }
    
    
}
