
package com.integracommerce.entidade.sku;

import com.integracommerce.entidade.atributos.Attribute;
import java.util.List;

public class Sku {
    
    public String IdSku; //Id do Sku (Obrigatório)
    public String IdSkuErp; // Id do Sku no ERP (Obrigatório)
    public String IdProduct; //id do Objeto produto
    public String Name;
    public String Description;
    public int Height; // Dimensão de altura em metros (Obrigatório)
    public int Width; // Dimensão de largura em metros (Obrigatório)
    public int Length; // Dimensão de comprimento em metros (Obrigatório)
    public int Weight; //Peso em Kg (Obrigatório)
    public String CodeEan; // EAN (Obrigatório)
    public String CodeNcm; // NCM (Opcional)
    public String CodeIsbn; // ISBN em caso do produto ser livro. Campo deve possuir 10 ou 13 caracteres. (Opcional)
    public String CodeNbm; // NBM do Sku (Opcional)
    public String Variation; // Variação (Opcional)
    public boolean Status; // Status do Sku (Obrigatório)
    public Price Price; //(Obrigatório)
    public int StockQuantity; //Quantidade em estoque (Obrigatório)
    public String MainImageUrl; //Adiciona a imagem como principal(Opcional)
    public List<String> UrlImages; //Urls das imagens do Sku (Opcional). Usar http e não https
    public List<Attribute> Attributes; // Atributos do Sku (Opcional)

    public String getIdSku() {
        return IdSku;
    }

    public void setIdSku(String IdSku) {
        this.IdSku = IdSku;
    }

    public String getIdSkuErp() {
        return IdSkuErp;
    }

    public void setIdSkuErp(String IdSkuErp) {
        this.IdSkuErp = IdSkuErp;
    }

    public String getIdProduct() {
        return IdProduct;
    }

    public void setIdProduct(String IdProduct) {
        this.IdProduct = IdProduct;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public int getHeight() {
        return Height;
    }

    public void setHeight(int Height) {
        this.Height = Height;
    }

    public int getWidth() {
        return Width;
    }

    public void setWidth(int Width) {
        this.Width = Width;
    }

    public int getLength() {
        return Length;
    }

    public void setLength(int Length) {
        this.Length = Length;
    }

    public int getWeight() {
        return Weight;
    }

    public void setWeight(int Weight) {
        this.Weight = Weight;
    }

    public String getCodeEan() {
        return CodeEan;
    }

    public void setCodeEan(String CodeEan) {
        this.CodeEan = CodeEan;
    }

    public String getCodeNcm() {
        return CodeNcm;
    }

    public void setCodeNcm(String CodeNcm) {
        this.CodeNcm = CodeNcm;
    }

    public String getCodeIsbn() {
        return CodeIsbn;
    }

    public void setCodeIsbn(String CodeIsbn) {
        this.CodeIsbn = CodeIsbn;
    }

    public String getCodeNbm() {
        return CodeNbm;
    }

    public void setCodeNbm(String CodeNbm) {
        this.CodeNbm = CodeNbm;
    }

    public String getVariation() {
        return Variation;
    }

    public void setVariation(String Variation) {
        this.Variation = Variation;
    }

    public boolean isStatus() {
        return Status;
    }

    public void setStatus(boolean Status) {
        this.Status = Status;
    }

    public Price getPrice() {
        return Price;
    }

    public void setPrice(Price Price) {
        this.Price = Price;
    }

    public int getStockQuantity() {
        return StockQuantity;
    }

    public void setStockQuantity(int StockQuantity) {
        this.StockQuantity = StockQuantity;
    }

    public String getMainImageUrl() {
        return MainImageUrl;
    }

    public void setMainImageUrl(String MainImageUrl) {
        this.MainImageUrl = MainImageUrl;
    }

    public List<String> getUrlImages() {
        return UrlImages;
    }

    public void setUrlImages(List<String> UrlImages) {
        this.UrlImages = UrlImages;
    }

    public List<Attribute> getAttributes() {
        return Attributes;
    }

    public void setAttributes(List<Attribute> Attributes) {
        this.Attributes = Attributes;
    }
    
    
}
