package com.integracommerce.entidade.pedido;

import java.util.List;

public class ShippingLabels {

    public String Url;
    public String ExpiresOn;
    public String Order;
    public String TrackingCode;
    public String TrackingUrl;
    public List<ShippingLabels> Orders;

    public String getUrl() {
        return Url;
    }

    public void setUrl(String Url) {
        this.Url = Url;
    }

    public String getExpiresOn() {
        return ExpiresOn;
    }

    public void setExpiresOn(String ExpiresOn) {
        this.ExpiresOn = ExpiresOn;
    }

    public String getOrder() {
        return Order;
    }

    public void setOrder(String Order) {
        this.Order = Order;
    }

    public String getTrackingCode() {
        return TrackingCode;
    }

    public void setTrackingCode(String TrackingCode) {
        this.TrackingCode = TrackingCode;
    }

    public String getTrackingUrl() {
        return TrackingUrl;
    }

    public void setTrackingUrl(String TrackingUrl) {
        this.TrackingUrl = TrackingUrl;
    }

    public List<ShippingLabels> getOrders() {
        return Orders;
    }

    public void setOrders(List<ShippingLabels> Orders) {
        this.Orders = Orders;
    }

}
