package com.integracommerce.entidade.pedido;

import java.util.List;
import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class ShippingLabels {

    private String Url;
    private String ExpiresOn;
    private List<InfoOrders> Orders;

    public ShippingLabels() {
    }

    public ShippingLabels(String Url, String ExpiresOn, List<InfoOrders> Orders) {
        this.Url = Url;
        this.ExpiresOn = ExpiresOn;
        this.Orders = Orders;
    }

    public String getUrl() {
        return Url;
    }

    public void setUrl(String Url) {
        this.Url = Url;
    }

    public String getExpiresOn() {
        return ExpiresOn;
    }

    public void setExpiresOn(String ExpiresOn) {
        this.ExpiresOn = ExpiresOn;
    }

    public List<InfoOrders> getOrders() {
        return Orders;
    }

    public void setOrders(List<InfoOrders> Orders) {
        this.Orders = Orders;
    }

}
