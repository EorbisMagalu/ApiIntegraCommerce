
package com.integracommerce.entidade.invoice;

public class Invoice {
    
    private String Key;
    private String Line;
    private String Number;
    private String IssueDate;

    public Invoice() {
    }

    public Invoice(String Key, String Line, String Number, String IssueDate) {
        this.Key = Key;
        this.Line = Line;
        this.Number = Number;
        this.IssueDate = IssueDate;
    }

    public String getKey() {
        return Key;
    }

    public void setKey(String Key) {
        this.Key = Key;
    }

    public String getLine() {
        return Line;
    }

    public void setLine(String Line) {
        this.Line = Line;
    }

    public String getNumber() {
        return Number;
    }

    public void setNumber(String Number) {
        this.Number = Number;
    }

    public String getIssueDate() {
        return IssueDate;
    }

    public void setIssueDate(String IssueDate) {
        this.IssueDate = IssueDate;
    }
}
//"IssueDate": "2021-06-14"