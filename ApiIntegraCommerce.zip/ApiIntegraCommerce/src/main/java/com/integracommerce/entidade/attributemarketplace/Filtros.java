package com.integracommerce.entidade.attributemarketplace;

import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

public class Filtros {
    
    private String marketplace;
    private Integer pageIndex;
    private Integer pageSize;
    
    public Filtros(String marketplace, Integer pageIndex, Integer pageSize) {
        this.marketplace = marketplace;
        this.pageIndex = pageIndex;
        this.pageSize = pageSize;
    }
    
    public Map<String, Object> params() {

        Map<String, Object> par = new HashMap<>();

        if (!StringUtils.isBlank(this.getMarketplace())) {
            par.put("marketplace", this.getMarketplace());
        }
        
        if (this.getPageIndex() != null && this.getPageIndex() >= 0) {
            par.put("pageIndex", this.getPageIndex());
        }

        if (this.getPageSize() != null && this.getPageSize() >= 0) {
            par.put("pageSize", this.getPageSize());
        }

        return par;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }

    public String getMarketplace() {
        return marketplace;
    }

    public void setMarketplace(String marketplace) {
        this.marketplace = marketplace;
    }
    
    
}
