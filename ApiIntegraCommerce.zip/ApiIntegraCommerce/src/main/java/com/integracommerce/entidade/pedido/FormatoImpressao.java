
package com.integracommerce.entidade.pedido;

public enum FormatoImpressao {
    PDF,
    ZPL;
}
