
package com.integracommerce.entidade.produto;

import java.util.List;

public class Produtos {
    
    public int Page;
    public int PerPage;
    public int Total;
    public List<Produto> Products;

    public int getPage() {
        return Page;
    }

    public void setPage(int Page) {
        this.Page = Page;
    }

    public int getPerPage() {
        return PerPage;
    }

    public void setPerPage(int PerPage) {
        this.PerPage = PerPage;
    }

    public int getTotal() {
        return Total;
    }

    public void setTotal(int Total) {
        this.Total = Total;
    }

    public List<Produto> getProducts() {
        return Products;
    }

    public void setProducts(List<Produto> Products) {
        this.Products = Products;
    }
    
    
}
