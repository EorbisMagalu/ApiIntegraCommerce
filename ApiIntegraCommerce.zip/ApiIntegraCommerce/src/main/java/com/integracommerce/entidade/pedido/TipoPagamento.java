
package com.integracommerce.entidade.pedido;

import org.apache.commons.lang3.EnumUtils;
import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonValue;

public enum TipoPagamento {
    
    //Boleto Bancário
    BANK_SLIP("bank_slip"),
    
    //MagaluPay
    ACCOUNT_BALANCE("account_balance"),
    
    //Cartão de Crédito
    CREDIT_CARD("credit_card"),
    
    //Cartão de Débito
    DEBIT_CARD("debit_card"),
    
    PIX("Pix");
    
    private final String value;

    private TipoPagamento(String value) {
        this.value = value;
    }
    
    @JsonValue
    public String getValue() {
        return value;
    }

    @JsonCreator
    public static TipoPagamento forValue(String name) {
        return EnumUtils.getEnumIgnoreCase(TipoPagamento.class, name);
    }
    
}
