
package com.integracommerce.entidade.skuqueue;

import java.util.List;

public class SkuQueue {
    
    public Integer Total;
    public Integer Id;
    public Integer IdSku;
    public String InsertedDate;
    public List<SkuQueue> SkusQueue;

    public Integer getTotal() {
        return Total;
    }

    public void setTotal(Integer Total) {
        this.Total = Total;
    }

    public Integer getId() {
        return Id;
    }

    public void setId(Integer Id) {
        this.Id = Id;
    }

    public Integer getIdSku() {
        return IdSku;
    }

    public void setIdSku(Integer IdSku) {
        this.IdSku = IdSku;
    }

    public String getInsertedDate() {
        return InsertedDate;
    }

    public void setInsertedDate(String InsertedDate) {
        this.InsertedDate = InsertedDate;
    }

    public List<SkuQueue> getSkusQueue() {
        return SkusQueue;
    }

    public void setSkusQueue(List<SkuQueue> SkusQueue) {
        this.SkusQueue = SkusQueue;
    }

    
    
}
