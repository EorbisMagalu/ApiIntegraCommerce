
package com.integracommerce.entidade.pedido;

import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class Products {
    
    private String IdSku;
    private Integer Quantity;
    private String Price;
    private String Freight;
    private String Discount;
    private Integer IdOrderPackage;

    public String getIdSku() {
        return IdSku;
    }

    public void setIdSku(String IdSku) {
        this.IdSku = IdSku;
    }

    public Integer getQuantity() {
        return Quantity;
    }

    public void setQuantity(Integer Quantity) {
        this.Quantity = Quantity;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String Price) {
        this.Price = Price;
    }

    public String getFreight() {
        return Freight;
    }

    public void setFreight(String Freight) {
        this.Freight = Freight;
    }

    public String getDiscount() {
        return Discount;
    }

    public void setDiscount(String Discount) {
        this.Discount = Discount;
    }

    public Integer getIdOrderPackage() {
        return IdOrderPackage;
    }

    public void setIdOrderPackage(Integer IdOrderPackage) {
        this.IdOrderPackage = IdOrderPackage;
    }

}
