
package com.integracommerce.entidade.categoria;

import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class CategoriesMarketplace {
    
    private String MarketPlaceName;
    private CategoryMarketplaceList CategoryMarketplaceList;

    public String getMarketPlaceName() {
        return MarketPlaceName;
    }

    public void setMarketPlaceName(String MarketPlaceName) {
        this.MarketPlaceName = MarketPlaceName;
    }

    public CategoryMarketplaceList getCategoryMarketplaceList() {
        return CategoryMarketplaceList;
    }

    public void setCategoryMarketplaceList(CategoryMarketplaceList CategoryMarketplaceList) {
        this.CategoryMarketplaceList = CategoryMarketplaceList;
    }

}
