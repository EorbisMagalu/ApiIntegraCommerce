
package com.integracommerce.entidade.pedido;

import java.util.List;
import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class Pedido {
    
    private String IdOrder;
    private String IdOrderMarketplace;
    private String InsertedDate;
    private String PurchasedDate;
    private String ApprovedDate;
    private String UpdatedDate;
    private String MarketplaceName;
    private String StoreName;
    private Boolean UpdatedMarketplaceStatus;
    private Boolean InsertedErp;
    private String EstimatedDeliveryDate;
    private String CustomerPfCpf;
    private String ReceiverName;
    private String CustomerPfName;
    private String CustomerPjCnpj;
    private String CustomerPjCorporatename;
    private String DeliveryAddressStreet;
    private String DeliveryAddressAdditionalInfo;
    private String DeliveryAddressZipcode;
    private String DeliveryAddressNeighborhood;
    private String DeliveryAddressCity;
    private String DeliveryAddressReference;
    private String DeliveryAddressState;
    private String DeliveryAddressNumber;
    private String TelephoneMainNumber;
    private String TelephoneSecundaryNumber;
    private String TelephoneBusinessNumber;
    private String TotalAmount;
    private String TotalTax;
    private String TotalFreight;
    private String TotalDiscount;
    private String CustomerMail;
    private String CustomerBirthDate;
    private String CustomerPjIe;
    private StatusPedido OrderStatus;
    private String InvoicedNumber;
    private Integer InvoicedLine;
    private String InvoicedIssueDate;
    private String InvoicedKey;
    private String InvoicedDanfeXml;
    private String ShippedTrackingUrl;
    private String ShippedTrackingProtocol;
    private String ShippedEstimatedDelivery;
    private String ShippedCarrierDate;
    private String ShippedCarrierName;
    private String ShipmentExceptionObservation;
    private String ShipmentExceptionOccurrenceDate; 
    private String DeliveredDate;
    private String ShippedCodeERP;
    private String BranchDocument;
    private String MarketplaceDocument;
    private String SellerName;
    private String GatewayPaymentDocument;
    private List<Products> Products;
    private List<Payments> Payments;
    

    public Pedido(String IdOrder, StatusPedido OrderStatus) {
        this.IdOrder = IdOrder;
        this.OrderStatus = OrderStatus;
    }
    
    public Pedido(String IdOrder, StatusPedido OrderStatus,String DeliveredDate) {
        this.IdOrder = IdOrder;
        this.OrderStatus = OrderStatus;
        this.DeliveredDate = DeliveredDate;
    }
    
    public Pedido(String IdOrder, StatusPedido OrderStatus, String InvoicedNumber, Integer InvoicedLine, String InvoicedIssueDate, String InvoicedKey, String InvoicedDanfeXml) {
        this.IdOrder = IdOrder;
        this.OrderStatus = OrderStatus;
        this.InvoicedNumber = InvoicedNumber;
        this.InvoicedLine = InvoicedLine;
        this.InvoicedIssueDate = InvoicedIssueDate;
        this.InvoicedKey = InvoicedKey;
        this.InvoicedDanfeXml = InvoicedDanfeXml;
    }

    public Pedido(String IdOrder, StatusPedido OrderStatus, String ShippedTrackingUrl, String ShippedTrackingProtocol, String ShippedEstimatedDelivery, String ShippedCarrierDate, String ShippedCarrierName) {
        this.IdOrder = IdOrder;
        this.OrderStatus = OrderStatus;
        this.ShippedTrackingUrl = ShippedTrackingUrl;
        this.ShippedTrackingProtocol = ShippedTrackingProtocol;
        this.ShippedEstimatedDelivery = ShippedEstimatedDelivery;
        this.ShippedCarrierDate = ShippedCarrierDate;
        this.ShippedCarrierName = ShippedCarrierName;
    }

    public Pedido(String IdOrder, StatusPedido OrderStatus, String ShipmentExceptionObservation, String ShipmentExceptionOccurrenceDate) {
        this.IdOrder = IdOrder;
        this.OrderStatus = OrderStatus;
        this.ShipmentExceptionObservation = ShipmentExceptionObservation;
        this.ShipmentExceptionOccurrenceDate = ShipmentExceptionOccurrenceDate;
    }
    
    public Pedido() {
    }
    
    public String getIdOrder() {
        return IdOrder;
    }

    public void setIdOrder(String IdOrder) {
        this.IdOrder = IdOrder;
    }

    public String getIdOrderMarketplace() {
        return IdOrderMarketplace;
    }

    public void setIdOrderMarketplace(String IdOrderMarketplace) {
        this.IdOrderMarketplace = IdOrderMarketplace;
    }

    public String getInsertedDate() {
        return InsertedDate;
    }

    public void setInsertedDate(String InsertedDate) {
        this.InsertedDate = InsertedDate;
    }

    public String getPurchasedDate() {
        return PurchasedDate;
    }

    public void setPurchasedDate(String PurchasedDate) {
        this.PurchasedDate = PurchasedDate;
    }

    public String getApprovedDate() {
        return ApprovedDate;
    }

    public void setApprovedDate(String ApprovedDate) {
        this.ApprovedDate = ApprovedDate;
    }

    public String getUpdatedDate() {
        return UpdatedDate;
    }

    public void setUpdatedDate(String UpdatedDate) {
        this.UpdatedDate = UpdatedDate;
    }

    public String getMarketplaceName() {
        return MarketplaceName;
    }

    public void setMarketplaceName(String MarketplaceName) {
        this.MarketplaceName = MarketplaceName;
    }

    public String getStoreName() {
        return StoreName;
    }

    public void setStoreName(String StoreName) {
        this.StoreName = StoreName;
    }

    public Boolean isUpdatedMarketplaceStatus() {
        return UpdatedMarketplaceStatus;
    }

    public void setUpdatedMarketplaceStatus(Boolean UpdatedMarketplaceStatus) {
        this.UpdatedMarketplaceStatus = UpdatedMarketplaceStatus;
    }

    public Boolean isInsertedErp() {
        return InsertedErp;
    }

    public void setInsertedErp(Boolean InsertedErp) {
        this.InsertedErp = InsertedErp;
    }

    public String getEstimatedDeliveryDate() {
        return EstimatedDeliveryDate;
    }

    public void setEstimatedDeliveryDate(String EstimatedDeliveryDate) {
        this.EstimatedDeliveryDate = EstimatedDeliveryDate;
    }

    public String getCustomerPfCpf() {
        return CustomerPfCpf;
    }

    public void setCustomerPfCpf(String CustomerPfCpf) {
        this.CustomerPfCpf = CustomerPfCpf;
    }

    public String getReceiverName() {
        return ReceiverName;
    }

    public void setReceiverName(String ReceiverName) {
        this.ReceiverName = ReceiverName;
    }

    public String getCustomerPfName() {
        return CustomerPfName;
    }

    public void setCustomerPfName(String CustomerPfName) {
        this.CustomerPfName = CustomerPfName;
    }

    public String getCustomerPjCnpj() {
        return CustomerPjCnpj;
    }

    public void setCustomerPjCnpj(String CustomerPjCnpj) {
        this.CustomerPjCnpj = CustomerPjCnpj;
    }

    public String getCustomerPjCorporatename() {
        return CustomerPjCorporatename;
    }

    public void setCustomerPjCorporatename(String CustomerPjCorporatename) {
        this.CustomerPjCorporatename = CustomerPjCorporatename;
    }

    public String getDeliveryAddressStreet() {
        return DeliveryAddressStreet;
    }

    public void setDeliveryAddressStreet(String DeliveryAddressStreet) {
        this.DeliveryAddressStreet = DeliveryAddressStreet;
    }

    public String getDeliveryAddressAdditionalInfo() {
        return DeliveryAddressAdditionalInfo;
    }

    public void setDeliveryAddressAdditionalInfo(String DeliveryAddressAdditionalInfo) {
        this.DeliveryAddressAdditionalInfo = DeliveryAddressAdditionalInfo;
    }

    public String getDeliveryAddressZipcode() {
        return DeliveryAddressZipcode;
    }

    public void setDeliveryAddressZipcode(String DeliveryAddressZipcode) {
        this.DeliveryAddressZipcode = DeliveryAddressZipcode;
    }

    public String getDeliveryAddressNeighborhood() {
        return DeliveryAddressNeighborhood;
    }

    public void setDeliveryAddressNeighborhood(String DeliveryAddressNeighborhood) {
        this.DeliveryAddressNeighborhood = DeliveryAddressNeighborhood;
    }

    public String getDeliveryAddressCity() {
        return DeliveryAddressCity;
    }

    public void setDeliveryAddressCity(String DeliveryAddressCity) {
        this.DeliveryAddressCity = DeliveryAddressCity;
    }

    public String getDeliveryAddressReference() {
        return DeliveryAddressReference;
    }

    public void setDeliveryAddressReference(String DeliveryAddressReference) {
        this.DeliveryAddressReference = DeliveryAddressReference;
    }

    public String getDeliveryAddressState() {
        return DeliveryAddressState;
    }

    public void setDeliveryAddressState(String DeliveryAddressState) {
        this.DeliveryAddressState = DeliveryAddressState;
    }

    public String getDeliveryAddressNumber() {
        return DeliveryAddressNumber;
    }

    public void setDeliveryAddressNumber(String DeliveryAddressNumber) {
        this.DeliveryAddressNumber = DeliveryAddressNumber;
    }

    public String getTelephoneMainNumber() {
        return TelephoneMainNumber;
    }

    public void setTelephoneMainNumber(String TelephoneMainNumber) {
        this.TelephoneMainNumber = TelephoneMainNumber;
    }

    public String getTelephoneSecundaryNumber() {
        return TelephoneSecundaryNumber;
    }

    public void setTelephoneSecundaryNumber(String TelephoneSecundaryNumber) {
        this.TelephoneSecundaryNumber = TelephoneSecundaryNumber;
    }

    public String getTelephoneBusinessNumber() {
        return TelephoneBusinessNumber;
    }

    public void setTelephoneBusinessNumber(String TelephoneBusinessNumber) {
        this.TelephoneBusinessNumber = TelephoneBusinessNumber;
    }

    public String getTotalAmount() {
        return TotalAmount;
    }

    public void setTotalAmount(String TotalAmount) {
        this.TotalAmount = TotalAmount;
    }

    public String getTotalTax() {
        return TotalTax;
    }

    public void setTotalTax(String TotalTax) {
        this.TotalTax = TotalTax;
    }

    public String getTotalFreight() {
        return TotalFreight;
    }

    public void setTotalFreight(String TotalFreight) {
        this.TotalFreight = TotalFreight;
    }

    public String getTotalDiscount() {
        return TotalDiscount;
    }

    public void setTotalDiscount(String TotalDiscount) {
        this.TotalDiscount = TotalDiscount;
    }

    public String getCustomerMail() {
        return CustomerMail;
    }

    public void setCustomerMail(String CustomerMail) {
        this.CustomerMail = CustomerMail;
    }

    public String getCustomerBirthDate() {
        return CustomerBirthDate;
    }

    public void setCustomerBirthDate(String CustomerBirthDate) {
        this.CustomerBirthDate = CustomerBirthDate;
    }

    public String getCustomerPjIe() {
        return CustomerPjIe;
    }

    public void setCustomerPjIe(String CustomerPjIe) {
        this.CustomerPjIe = CustomerPjIe;
    }

    public StatusPedido getOrderStatus() {
        return OrderStatus;
    }

    public void setOrderStatus(StatusPedido OrderStatus) {
        this.OrderStatus = OrderStatus;
    }

    public String getInvoicedNumber() {
        return InvoicedNumber;
    }

    public void setInvoicedNumber(String InvoicedNumber) {
        this.InvoicedNumber = InvoicedNumber;
    }

    public Integer getInvoicedLine() {
        return InvoicedLine;
    }

    public void setInvoicedLine(Integer InvoicedLine) {
        this.InvoicedLine = InvoicedLine;
    }

    public String getInvoicedIssueDate() {
        return InvoicedIssueDate;
    }

    public void setInvoicedIssueDate(String InvoicedIssueDate) {
        this.InvoicedIssueDate = InvoicedIssueDate;
    }

    public String getInvoicedKey() {
        return InvoicedKey;
    }

    public void setInvoicedKey(String InvoicedKey) {
        this.InvoicedKey = InvoicedKey;
    }

    public String getInvoicedDanfeXml() {
        return InvoicedDanfeXml;
    }

    public void setInvoicedDanfeXml(String InvoicedDanfeXml) {
        this.InvoicedDanfeXml = InvoicedDanfeXml;
    }

    public String getShippedTrackingUrl() {
        return ShippedTrackingUrl;
    }

    public void setShippedTrackingUrl(String ShippedTrackingUrl) {
        this.ShippedTrackingUrl = ShippedTrackingUrl;
    }

    public String getShippedTrackingProtocol() {
        return ShippedTrackingProtocol;
    }

    public void setShippedTrackingProtocol(String ShippedTrackingProtocol) {
        this.ShippedTrackingProtocol = ShippedTrackingProtocol;
    }

    public String getShippedEstimatedDelivery() {
        return ShippedEstimatedDelivery;
    }

    public void setShippedEstimatedDelivery(String ShippedEstimatedDelivery) {
        this.ShippedEstimatedDelivery = ShippedEstimatedDelivery;
    }

    public String getShippedCarrierDate() {
        return ShippedCarrierDate;
    }

    public void setShippedCarrierDate(String ShippedCarrierDate) {
        this.ShippedCarrierDate = ShippedCarrierDate;
    }

    public String getShippedCarrierName() {
        return ShippedCarrierName;
    }

    public void setShippedCarrierName(String ShippedCarrierName) {
        this.ShippedCarrierName = ShippedCarrierName;
    }

    public String getShipmentExceptionObservation() {
        return ShipmentExceptionObservation;
    }

    public void setShipmentExceptionObservation(String ShipmentExceptionObservation) {
        this.ShipmentExceptionObservation = ShipmentExceptionObservation;
    }

    public String getShipmentExceptionOccurrenceDate() {
        return ShipmentExceptionOccurrenceDate;
    }

    public void setShipmentExceptionOccurrenceDate(String ShipmentExceptionOccurrenceDate) {
        this.ShipmentExceptionOccurrenceDate = ShipmentExceptionOccurrenceDate;
    }

    public String getDeliveredDate() {
        return DeliveredDate;
    }

    public void setDeliveredDate(String DeliveredDate) {
        this.DeliveredDate = DeliveredDate;
    }

    public String getShippedCodeERP() {
        return ShippedCodeERP;
    }

    public void setShippedCodeERP(String ShippedCodeERP) {
        this.ShippedCodeERP = ShippedCodeERP;
    }

    public String getBranchDocument() {
        return BranchDocument;
    }

    public void setBranchDocument(String BranchDocument) {
        this.BranchDocument = BranchDocument;
    }

    public String getMarketplaceDocument() {
        return MarketplaceDocument;
    }

    public void setMarketplaceDocument(String MarketplaceDocument) {
        this.MarketplaceDocument = MarketplaceDocument;
    }

    public String getSellerName() {
        return SellerName;
    }

    public void setSellerName(String SellerName) {
        this.SellerName = SellerName;
    }

    public String getGatewayPaymentDocument() {
        return GatewayPaymentDocument;
    }

    public void setGatewayPaymentDocument(String GatewayPaymentDocument) {
        this.GatewayPaymentDocument = GatewayPaymentDocument;
    }

    public List<Products> getProducts() {
        return Products;
    }

    public void setProducts(List<Products> Products) {
        this.Products = Products;
    }

    public List<Payments> getPayments() {
        return Payments;
    }

    public void setPayments(List<Payments> Payments) {
        this.Payments = Payments;
    }
}