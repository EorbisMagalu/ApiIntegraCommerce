
package com.integracommerce.entidade.stock;

import java.util.List;

public class Stock {
    
    public String IdSku;
    public int Quantity;
    public List<Stock> Stock;

    public String getIdSku() {
        return IdSku;
    }

    public void setIdSku(String IdSku) {
        this.IdSku = IdSku;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }

    public List<Stock> getStock() {
        return Stock;
    }

    public void setStock(List<Stock> Stock) {
        this.Stock = Stock;
    }
    
    
}
