package com.integracommerce.entidade.orderqueue;

import org.codehaus.jackson.annotate.JsonValue;

public enum Status {

    NEW("NEW"),
    APPROVED("APPROVED"),
    CANCELED("CANCELED");

    private final String value;

    private Status(String value) {
        this.value = value;
    }

    @JsonValue
    public String getValue() {
        return value;
    }

}
