package com.integracommerce.entidade.atributos;

import java.util.HashMap;
import java.util.Map;

public class Filtros {

    private Boolean isSku;
    private Boolean isProduct;
    private Integer page;
    private Integer perPage;
   

    public Filtros(Boolean isSku, Boolean isProduct, Integer page, Integer perPage) {
        this.isSku = isSku;
        this.isProduct = isProduct;
        this.page = page;
        this.perPage = perPage;
    }

    public Filtros() {
        this.isSku = null;
        this.isProduct = null;
    }

    public Map<String, Object> params() {

        Map<String, Object> par = new HashMap<>();

        if (this.getSku() != null) {
            par.put("isSku", this.getSku());
        }

        if (this.getProduct() != null) {
            par.put("isProduct", this.getProduct());
        }

        if (this.getPage() != null && this.getPage() >= 0) {
            par.put("page", this.getPage());
        }

        if (this.getPerPage() != null && !(this.getPerPage() < 0)) {
            par.put("perPage", this.getPerPage());
        }

        return par;
    }

    public Boolean getIsSku() {
        return isSku;
    }

    public void setIsSku(Boolean isSku) {
        this.isSku = isSku;
    }

    public Boolean getIsProduct() {
        return isProduct;
    }

    public void setIsProduct(Boolean isProduct) {
        this.isProduct = isProduct;
    }

    public Boolean getSku() {
        return isSku;
    }

    public void setSku(Boolean isSku) {
        this.isSku = isSku;
    }

    public Boolean getProduct() {
        return isProduct;
    }

    public void setProduct(Boolean isProduct) {
        this.isProduct = isProduct;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getPerPage() {
        return perPage;
    }

    public void setPerPage(Integer perPage) {
        this.perPage = perPage;
    }

}
