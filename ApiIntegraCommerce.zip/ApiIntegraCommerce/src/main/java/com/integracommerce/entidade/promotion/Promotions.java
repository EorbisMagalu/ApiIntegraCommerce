
package com.integracommerce.entidade.promotion;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class Promotions {
    
    public int Page;
    public int PerPage;
    public int TotalPage;
    public String Id;
    public String Name;
    public String Description;
    public String PromotionType;
    public BigDecimal DiscountInPercent;
    public Date Deadline;
    public Date StartDate;
    public Date EndDate;
    public boolean Status;
    public int QuantitySku;
    public boolean ActiveSeller;
    public String PromotionChannel;
    public boolean AllowedToDeleteSku;
    public boolean AllowedToInactiveSellerPromotion;
    public BigDecimal MinDiscountPercents;
    public BigDecimal MaxDiscountPercents;
    public List<Promotions> Promotions;

    public int getPage() {
        return Page;
    }

    public void setPage(int Page) {
        this.Page = Page;
    }

    public int getPerPage() {
        return PerPage;
    }

    public void setPerPage(int PerPage) {
        this.PerPage = PerPage;
    }

    public int getTotalPage() {
        return TotalPage;
    }

    public void setTotalPage(int TotalPage) {
        this.TotalPage = TotalPage;
    }

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public String getPromotionType() {
        return PromotionType;
    }

    public void setPromotionType(String PromotionType) {
        this.PromotionType = PromotionType;
    }

    public BigDecimal getDiscountInPercent() {
        return DiscountInPercent;
    }

    public void setDiscountInPercent(BigDecimal DiscountInPercent) {
        this.DiscountInPercent = DiscountInPercent;
    }

    public Date getDeadline() {
        return Deadline;
    }

    public void setDeadline(Date Deadline) {
        this.Deadline = Deadline;
    }

    public Date getStartDate() {
        return StartDate;
    }

    public void setStartDate(Date StartDate) {
        this.StartDate = StartDate;
    }

    public Date getEndDate() {
        return EndDate;
    }

    public void setEndDate(Date EndDate) {
        this.EndDate = EndDate;
    }

    public boolean isStatus() {
        return Status;
    }

    public void setStatus(boolean Status) {
        this.Status = Status;
    }

    public int getQuantitySku() {
        return QuantitySku;
    }

    public void setQuantitySku(int QuantitySku) {
        this.QuantitySku = QuantitySku;
    }

    public boolean isActiveSeller() {
        return ActiveSeller;
    }

    public void setActiveSeller(boolean ActiveSeller) {
        this.ActiveSeller = ActiveSeller;
    }

    public String getPromotionChannel() {
        return PromotionChannel;
    }

    public void setPromotionChannel(String PromotionChannel) {
        this.PromotionChannel = PromotionChannel;
    }

    public boolean isAllowedToDeleteSku() {
        return AllowedToDeleteSku;
    }

    public void setAllowedToDeleteSku(boolean AllowedToDeleteSku) {
        this.AllowedToDeleteSku = AllowedToDeleteSku;
    }

    public boolean isAllowedToInactiveSellerPromotion() {
        return AllowedToInactiveSellerPromotion;
    }

    public void setAllowedToInactiveSellerPromotion(boolean AllowedToInactiveSellerPromotion) {
        this.AllowedToInactiveSellerPromotion = AllowedToInactiveSellerPromotion;
    }

    public BigDecimal getMinDiscountPercents() {
        return MinDiscountPercents;
    }

    public void setMinDiscountPercents(BigDecimal MinDiscountPercents) {
        this.MinDiscountPercents = MinDiscountPercents;
    }

    public BigDecimal getMaxDiscountPercents() {
        return MaxDiscountPercents;
    }

    public void setMaxDiscountPercents(BigDecimal MaxDiscountPercents) {
        this.MaxDiscountPercents = MaxDiscountPercents;
    }

    public List<Promotions> getPromotions() {
        return Promotions;
    }

    public void setPromotions(List<Promotions> Promotions) {
        this.Promotions = Promotions;
    }
    
    
    
}
