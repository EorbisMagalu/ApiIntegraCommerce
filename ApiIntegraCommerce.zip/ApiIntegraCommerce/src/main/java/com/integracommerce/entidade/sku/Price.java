package com.integracommerce.entidade.sku;

import java.math.BigDecimal;

public class Price {
    
    public String IdSku;
    public BigDecimal ListPrice;
    public BigDecimal SalePrice;

    public Price() {
    }

    public Price(String IdSku, BigDecimal ListPrice, BigDecimal SalePrice) {
        this.IdSku = IdSku;
        this.ListPrice = ListPrice;
        this.SalePrice = SalePrice;
    }
    
    public BigDecimal getListPrice() {
        return ListPrice;
    }

    public void setListPrice(BigDecimal ListPrice) {
        this.ListPrice = ListPrice;
    }

    public BigDecimal getSalePrice() {
        return SalePrice;
    }

    public void setSalePrice(BigDecimal SalePrice) {
        this.SalePrice = SalePrice;
    }

    public String getIdSku() {
        return IdSku;
    }

    public void setIdSku(String IdSku) {
        this.IdSku = IdSku;
    }

}
