package com.integracommerce.entidade.sku;

import java.math.BigDecimal;
import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class Price {
    
    private String IdSku;
    private String ListPrice;
    private String SalePrice;

    public Price() {
    }

    public Price(String IdSku, String ListPrice, String SalePrice) {
        this.IdSku = IdSku;
        this.ListPrice = ListPrice;
        this.SalePrice = SalePrice;
    }
    
    public String getListPrice() {
        return ListPrice;
    }

    public void setListPrice(String ListPrice) {
        this.ListPrice = ListPrice;
    }

    public String getSalePrice() {
        return SalePrice;
    }

    public void setSalePrice(String SalePrice) {
        this.SalePrice = SalePrice;
    }

    public String getIdSku() {
        return IdSku;
    }

    public void setIdSku(String IdSku) {
        this.IdSku = IdSku;
    }

}
