
package com.integracommerce.entidade.pedido;

import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class InfoOrders {
    
    private String Order;
    private String TrackingCode;
    private String TrackingUrl;

    public InfoOrders() {
    }

    public InfoOrders(String Order, String TrackingCode, String TrackingUrl) {
        this.Order = Order;
        this.TrackingCode = TrackingCode;
        this.TrackingUrl = TrackingUrl;
    }
    
    public String getOrder() {
        return Order;
    }

    public void setOrder(String Order) {
        this.Order = Order;
    }

    public String getTrackingCode() {
        return TrackingCode;
    }

    public void setTrackingCode(String TrackingCode) {
        this.TrackingCode = TrackingCode;
    }

    public String getTrackingUrl() {
        return TrackingUrl;
    }

    public void setTrackingUrl(String TrackingUrl) {
        this.TrackingUrl = TrackingUrl;
    }
    
    
}
