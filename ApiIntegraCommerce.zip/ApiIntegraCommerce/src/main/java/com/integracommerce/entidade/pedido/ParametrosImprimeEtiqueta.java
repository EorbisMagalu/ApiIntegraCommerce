
package com.integracommerce.entidade.pedido;

import java.util.List;
import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class ParametrosImprimeEtiqueta {
    
    private FormatoImpressao Format;
    private List<String> Orders;

    public ParametrosImprimeEtiqueta(FormatoImpressao Format, List<String> Orders) {
        this.Format = Format;
        this.Orders = Orders;
    }
    
    public FormatoImpressao getFormat() {
        return Format;
    }

    public void setFormat(FormatoImpressao Format) {
        this.Format = Format;
    }

    public List<String> getOrders() {
        return Orders;
    }

    public void setOrders(List<String> Orders) {
        this.Orders = Orders;
    }
    
    
    
}
