
package com.integracommerce.entidade.skushipping;

public class SkuShipping {
    
    public String Sku;

    public String getSku() {
        return Sku;
    }

    public void setSku(String Sku) {
        this.Sku = Sku;
    }

}
