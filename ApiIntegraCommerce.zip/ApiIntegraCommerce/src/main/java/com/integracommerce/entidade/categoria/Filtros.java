package com.integracommerce.entidade.categoria;

import java.util.LinkedHashMap;
import java.util.Map;

public class Filtros {

    private Integer level;
    private Integer page;
    private Integer perPage;

    public Filtros() {
    }

    public Filtros(Integer level, Integer page, Integer perPage) {
        this.level = level;
        this.page = page;
        this.perPage = perPage;
    }

    public Map<String, Object> params() {

        Map<String, Object> par = new LinkedHashMap<>();

        if (this.getLevel() != null && this.getLevel() >= 0) {
            par.put("level", this.getLevel());
        }

        if (this.getPage() != null && this.getPage() >= 0) {
            par.put("page", this.getPage());
        }

        if (this.getPerPage() != null && !(this.getPerPage() < 0)) {
            par.put("perPage", this.getPerPage());
        }

        return par;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getPerPage() {
        return perPage;
    }

    public void setPerPage(Integer perPage) {
        this.perPage = perPage;
    }
}
