
package com.integracommerce.entidade.pricequeue;

import java.math.BigDecimal;
import java.util.List;

public class PriceQueue {
    
    public String Id;
    public String IdSku;
    public String InsertedDate;
    public BigDecimal PriceList;
    public BigDecimal PriceSale;
    public int Total;
    public List<PriceQueue> PriceQueues;

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public String getIdSku() {
        return IdSku;
    }

    public void setIdSku(String IdSku) {
        this.IdSku = IdSku;
    }

    public String getInsertedDate() {
        return InsertedDate;
    }

    public void setInsertedDate(String InsertedDate) {
        this.InsertedDate = InsertedDate;
    }

    public BigDecimal getPriceList() {
        return PriceList;
    }

    public void setPriceList(BigDecimal PriceList) {
        this.PriceList = PriceList;
    }

    public BigDecimal getPriceSale() {
        return PriceSale;
    }

    public void setPriceSale(BigDecimal PriceSale) {
        this.PriceSale = PriceSale;
    }

    public int getTotal() {
        return Total;
    }

    public void setTotal(int Total) {
        this.Total = Total;
    }

    public List<PriceQueue> getPriceQueues() {
        return PriceQueues;
    }

    public void setPriceQueues(List<PriceQueue> PriceQueues) {
        this.PriceQueues = PriceQueues;
    }
    
}