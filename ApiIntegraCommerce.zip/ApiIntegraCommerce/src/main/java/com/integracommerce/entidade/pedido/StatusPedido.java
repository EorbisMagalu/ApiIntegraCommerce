
package com.integracommerce.entidade.pedido;
import org.codehaus.jackson.annotate.JsonValue;

public enum StatusPedido {

    INVOICED("INVOICED"),
    SHIPPED("SHIPPED"),
    DELIVERED("DELIVERED"),
    SHIPMENTEXCEPTION("SHIPMENTEXCEPTION"),
    CANCELED("CANCELED"),
    NEW("NEW"),
    APPROVED("APPROVED"),
    PROCESSING("PROCESSING");
    
    private String value;
    
    private StatusPedido(String value) {
        this.value = value;
    }
    
    @JsonValue
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
