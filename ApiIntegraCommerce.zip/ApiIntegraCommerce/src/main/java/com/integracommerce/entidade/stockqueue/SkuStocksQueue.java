package com.integracommerce.entidade.stockqueue;

/**
 *
 * @author metaprime
 */
public class SkuStocksQueue {

    public int Id;
    public int IdSku;
    public int Total;
    public String InsertedDate;

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public int getIdSku() {
        return IdSku;
    }

    public void setIdSku(int IdSku) {
        this.IdSku = IdSku;
    }

    public int getTotal() {
        return Total;
    }

    public void setTotal(int Total) {
        this.Total = Total;
    }

    public String getInsertedDate() {
        return InsertedDate;
    }

    public void setInsertedDate(String InsertedDate) {
        this.InsertedDate = InsertedDate;
    }
    
    
}
