package com.integracommerce.entidade.promotion;

import java.math.BigDecimal;
import java.util.List;

public class Promotion {

    public String IdSku;
    public BigDecimal ListPrice;
    public BigDecimal SalePrice;
    public String StartDate;
    public String EndDate;
    public List<Promotion> Promotions;

    public String getIdSku() {
        return IdSku;
    }

    public void setIdSku(String IdSku) {
        this.IdSku = IdSku;
    }

    public BigDecimal getListPrice() {
        return ListPrice;
    }

    public void setListPrice(BigDecimal ListPrice) {
        this.ListPrice = ListPrice;
    }

    public BigDecimal getSalePrice() {
        return SalePrice;
    }

    public void setSalePrice(BigDecimal SalePrice) {
        this.SalePrice = SalePrice;
    }

    public String getStartDate() {
        return StartDate;
    }

    public void setStartDate(String StartDate) {
        this.StartDate = StartDate;
    }

    public String getEndDate() {
        return EndDate;
    }

    public void setEndDate(String EndDate) {
        this.EndDate = EndDate;
    }

    public List<Promotion> getPromotions() {
        return Promotions;
    }

    public void setPromotions(List<Promotion> Promotions) {
        this.Promotions = Promotions;
    }

}
