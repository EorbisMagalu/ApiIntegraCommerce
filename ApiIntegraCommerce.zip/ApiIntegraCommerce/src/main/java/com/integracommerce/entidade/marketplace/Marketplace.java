
package com.integracommerce.entidade.marketplace;

import java.util.List;
import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class Marketplace {
    
    private String Name;
    private List<Marketplace> Marketplaces;

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public List<Marketplace> getMarketplaces() {
        return Marketplaces;
    }

    public void setMarketplaces(List<Marketplace> Marketplaces) {
        this.Marketplaces = Marketplaces;
    }

}
