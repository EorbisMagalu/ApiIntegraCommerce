
package com.integracommerce.entidade.sku;

import java.util.List;
import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class Skus {
    
    private Integer Page;
    private Integer PerPage;
    private Integer Total;
    private List<Sku> Skus;

    public Integer getPage() {
        return Page;
    }

    public void setPage(Integer Page) {
        this.Page = Page;
    }

    public Integer getPerPage() {
        return PerPage;
    }

    public void setPerPage(Integer PerPage) {
        this.PerPage = PerPage;
    }

    public Integer getTotal() {
        return Total;
    }

    public void setTotal(Integer Total) {
        this.Total = Total;
    }

    public List<Sku> getSkus() {
        return Skus;
    }

    public void setSkus(List<Sku> Skus) {
        this.Skus = Skus;
    }

}
