
package com.integracommerce.entidade.sku;

import java.util.List;

public class Skus {
    
    public int Page;
    public int PerPage;
    public int Total;
    public List<Sku> Skus;

    public int getPage() {
        return Page;
    }

    public void setPage(int Page) {
        this.Page = Page;
    }

    public int getPerPage() {
        return PerPage;
    }

    public void setPerPage(int PerPage) {
        this.PerPage = PerPage;
    }

    public int getTotal() {
        return Total;
    }

    public void setTotal(int Total) {
        this.Total = Total;
    }

    public List<Sku> getSkus() {
        return Skus;
    }

    public void setSkus(List<Sku> Skus) {
        this.Skus = Skus;
    }
}
