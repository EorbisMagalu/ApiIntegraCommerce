
package com.integracommerce.entidade.stockqueue;

import java.util.List;

public class StockQueue {
    
    public int Total;
    public List<SkuStocksQueue> SkuStocksQueue;

    public int getTotal() {
        return Total;
    }

    public void setTotal(int Total) {
        this.Total = Total;
    }

    public List<SkuStocksQueue> getSkuStocksQueue() {
        return SkuStocksQueue;
    }

    public void setSkuStocksQueue(List<SkuStocksQueue> SkuStocksQueue) {
        this.SkuStocksQueue = SkuStocksQueue;
    }

}
