
package com.integracommerce.entidade.promotion;

import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;


public class Filtros {
    
    public String StartDate;
    public String EndDate;
    public String PromotionType;
    public Integer Page;
    public Integer PerPage;
    public String PromotionName;
    public String Sort;
    public Boolean Status;
    public Boolean Expired;

    public Filtros(String StartDate, String EndDate, String PromotionType, Integer Page, Integer PerPage, String PromotionName, String Sort, Boolean Status, Boolean Expired) {
        this.StartDate = StartDate;
        this.EndDate = EndDate;
        this.PromotionType = PromotionType;
        this.Page = Page;
        this.PerPage = PerPage;
        this.PromotionName = PromotionName;
        this.Sort = Sort;
        this.Status = Status;
        this.Expired = Expired;
    }

    public Filtros(String StartDate, String EndDate) {
        this.StartDate = StartDate;
        this.EndDate = EndDate;
    }

    public Filtros() {
        this.Expired = null;
        this.Status = null;
    }
    
    public String getStartDate() {
        return StartDate;
    }

    public void setStartDate(String StartDate) {
        this.StartDate = StartDate;
    }

    public String getEndDate() {
        return EndDate;
    }

    public void setEndDate(String EndDate) {
        this.EndDate = EndDate;
    }

    public String getPromotionType() {
        return PromotionType;
    }

    public void setPromotionType(String PromotionType) {
        this.PromotionType = PromotionType;
    }

    public Integer getPage() {
        return Page;
    }

    public void setPage(Integer Page) {
        this.Page = Page;
    }

    public Integer getPerPage() {
        return PerPage;
    }

    public void setPerPage(Integer PerPage) {
        this.PerPage = PerPage;
    }

    public String getPromotionName() {
        return PromotionName;
    }

    public void setPromotionName(String PromotionName) {
        this.PromotionName = PromotionName;
    }

    public String getSort() {
        return Sort;
    }

    public void setSort(String Sort) {
        this.Sort = Sort;
    }

    public Boolean isStatus() {
        return Status;
    }

    public void setStatus(Boolean Status) {
        this.Status = Status;
    }

    public Boolean isExpired() {
        return Expired;
    }

    public void setExpired(Boolean Expired) {
        this.Expired = Expired;
    }
    
    public Map<String, Object> params() {
        
        Map<String,Object> par = new HashMap<>();
        
        if(!StringUtils.isBlank(this.getStartDate())) {
            par.put("filter.startDate", this.getStartDate());
        }
        
        if(!StringUtils.isBlank(this.getEndDate())) {
            par.put("filter.endDate", this.getEndDate());
        }
        
        if(!StringUtils.isBlank(this.getPromotionType())) {
            par.put("filter.promotionType", this.getPromotionType());
        }
        
        if(this.getPage() > 0) {
            par.put("filter.page", this.getPage());
        }
        
        if(this.getPerPage()> 0) {
            par.put("filter.perPage", this.getPerPage());
        }
        
        if(!StringUtils.isBlank(this.getPromotionName())) {
            par.put("filter.promotionName", this.getPromotionName());
        }
        
        if(!StringUtils.isBlank(this.getSort())) {
            par.put("filter.sort", this.getSort());
        }
        
        if(this.isExpired() != null) {
            par.put("filter.expired", this.isExpired());
        }
        if(this.isStatus() != null) {
            par.put("filter.status",  this.isStatus());
        }
        
        return par;
    }
    
}
