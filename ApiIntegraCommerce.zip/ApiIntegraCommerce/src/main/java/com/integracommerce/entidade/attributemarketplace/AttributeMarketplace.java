
package com.integracommerce.entidade.attributemarketplace;

public class AttributeMarketplace {
    
    private String Name;
    private int MapsToMarketplaceAttributeId;

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getMapsToMarketplaceAttributeId() {
        return MapsToMarketplaceAttributeId;
    }

    public void setMapsToMarketplaceAttributeId(int MapsToMarketplaceAttributeId) {
        this.MapsToMarketplaceAttributeId = MapsToMarketplaceAttributeId;
    }
    
    
}
