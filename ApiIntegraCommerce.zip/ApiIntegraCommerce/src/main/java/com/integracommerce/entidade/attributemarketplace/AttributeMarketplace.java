
package com.integracommerce.entidade.attributemarketplace;

public class AttributeMarketplace {
    
    private String Name;
    private Integer MapsToMarketplaceAttributeId;

    public AttributeMarketplace(String Name, Integer MapsToMarketplaceAttributeId) {
        this.Name = Name;
        this.MapsToMarketplaceAttributeId = MapsToMarketplaceAttributeId;
    }

    public AttributeMarketplace() {
    }
    
    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public Integer getMapsToMarketplaceAttributeId() {
        return MapsToMarketplaceAttributeId;
    }

    public void setMapsToMarketplaceAttributeId(Integer MapsToMarketplaceAttributeId) {
        this.MapsToMarketplaceAttributeId = MapsToMarketplaceAttributeId;
    }
    
    
}
