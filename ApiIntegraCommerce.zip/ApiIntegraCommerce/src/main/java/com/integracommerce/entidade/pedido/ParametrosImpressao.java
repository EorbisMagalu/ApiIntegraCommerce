
package com.integracommerce.entidade.pedido;

import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class ParametrosImpressao {
    
    private FormatoImpressao Format;
    private String[] Orders;

    public ParametrosImpressao() {
    }

    public ParametrosImpressao(FormatoImpressao Format, String[] Orders) {
        this.Format = Format;
        this.Orders = Orders;
    }

    public FormatoImpressao getFormat() {
        return Format;
    }

    public void setFormat(FormatoImpressao Format) {
        this.Format = Format;
    }

    public String[] getOrders() {
        return Orders;
    }

    public void setOrders(String[] Orders) {
        this.Orders = Orders;
    }
}
