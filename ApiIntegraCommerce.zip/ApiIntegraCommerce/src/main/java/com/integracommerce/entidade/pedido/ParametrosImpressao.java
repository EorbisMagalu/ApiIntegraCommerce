
package com.integracommerce.entidade.pedido;

public class ParametrosImpressao {
    
    public FormatoImpressao Format;
    public String[] Orders;

    public ParametrosImpressao() {
    }

    public ParametrosImpressao(FormatoImpressao Format, String[] Orders) {
        this.Format = Format;
        this.Orders = Orders;
    }

    public FormatoImpressao getFormat() {
        return Format;
    }

    public void setFormat(FormatoImpressao Format) {
        this.Format = Format;
    }

    public String[] getOrders() {
        return Orders;
    }

    public void setOrders(String[] Orders) {
        this.Orders = Orders;
    }
}
