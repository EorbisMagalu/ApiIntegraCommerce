package com.integracommerce.entidade.categoria;

import java.util.List;
import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class Categorias {

    private int Page;
    private int PerPage;
    private int Total;
    private List<Categoria> Categories;
    private List<CategoriesMarketplace> CategoriesMarketplace;

    public int getPage() {
        return Page;
    }

    public void setPage(int Page) {
        this.Page = Page;
    }

    public int getPerPage() {
        return PerPage;
    }

    public void setPerPage(int PerPage) {
        this.PerPage = PerPage;
    }

    public int getTotal() {
        return Total;
    }

    public void setTotal(int Total) {
        this.Total = Total;
    }

    public List<Categoria> getCategories() {
        return Categories;
    }

    public void setCategories(List<Categoria> Categories) {
        this.Categories = Categories;
    }

    public List<CategoriesMarketplace> getCategoriesMarketplace() {
        return CategoriesMarketplace;
    }

    public void setCategoriesMarketplace(List<CategoriesMarketplace> CategoriesMarketplace) {
        this.CategoriesMarketplace = CategoriesMarketplace;
    }

    
    
}