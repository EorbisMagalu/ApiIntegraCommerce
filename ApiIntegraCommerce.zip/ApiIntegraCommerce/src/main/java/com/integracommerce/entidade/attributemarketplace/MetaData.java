
package com.integracommerce.entidade.attributemarketplace;

public class MetaData {
    
    public int PageCount;
    public int TotalItemCount;
    public int PageNumber;
    public int PageSize;
    public boolean HasPreviousPage;
    public boolean HasNextPage;

    public int getPageCount() {
        return PageCount;
    }

    public void setPageCount(int PageCount) {
        this.PageCount = PageCount;
    }

    public int getTotalItemCount() {
        return TotalItemCount;
    }

    public void setTotalItemCount(int TotalItemCount) {
        this.TotalItemCount = TotalItemCount;
    }

    public int getPageNumber() {
        return PageNumber;
    }

    public void setPageNumber(int PageNumber) {
        this.PageNumber = PageNumber;
    }

    public int getPageSize() {
        return PageSize;
    }

    public void setPageSize(int PageSize) {
        this.PageSize = PageSize;
    }

    public boolean isHasPreviousPage() {
        return HasPreviousPage;
    }

    public void setHasPreviousPage(boolean HasPreviousPage) {
        this.HasPreviousPage = HasPreviousPage;
    }

    public boolean isHasNextPage() {
        return HasNextPage;
    }

    public void setHasNextPage(boolean HasNextPage) {
        this.HasNextPage = HasNextPage;
    }
    
    
    
}
