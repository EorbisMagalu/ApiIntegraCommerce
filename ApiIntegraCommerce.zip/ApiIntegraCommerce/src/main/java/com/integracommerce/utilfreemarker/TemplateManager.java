package com.integracommerce.utilfreemarker;

import freemarker.cache.StringTemplateLoader;
import freemarker.ext.beans.BeansWrapperBuilder;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;
import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;

public class TemplateManager {

    private static Configuration cfg;

    public TemplateManager() {
        if(cfg == null) {
            cfg = new Configuration(Configuration.VERSION_2_3_31);
            cfg.setTagSyntax(Configuration.ANGLE_BRACKET_TAG_SYNTAX);
            cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
            cfg.setDefaultEncoding("UTF-8");
            cfg.setNumberFormat("computer");
            cfg.setLogTemplateExceptions(false);
            cfg.setWrapUncheckedExceptions(true);
            cfg.setFallbackOnNullLoopVariable(false);
            cfg.setObjectWrapper(new BeansWrapperBuilder(Configuration.VERSION_2_3_31).build());
            cfg.setTemplateLoader(new StringTemplateLoader());
        }
    }

    private Template loadTemplate(String templateName, String templatePath) {
        try {
            String templateContent = new String(Files.readAllBytes(Paths.get(templatePath)));
            ((StringTemplateLoader) cfg.getTemplateLoader()).putTemplate(templateName, templateContent);
            return cfg.getTemplate(templateName);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public String processTemplate(String templateName, Map<String, Object> data) {
        Path root = FileSystems.getDefault().getPath(".").toAbsolutePath();
        Path filePath = Paths.get(root.toString(), "src", "main", "java", "com", "integracommerce", "templates");
        Template template = loadTemplate(templateName, filePath.toFile() + File.separator + templateName + ".ftl");
        try (StringWriter writer = new StringWriter()) {
            template.process(data, writer);
            return writer.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
