
package com.integracommerce.utilfreemarker;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

public class ServiceUtil {
    
    public static Object getObjectJsonRequest(final String url) {
        try {
            HttpGet get = new HttpGet(url);
            get.setHeader("Content-Type", "application/json");
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(get);
            String strResponse = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            return JsonUtil.jsonToMap(strResponse);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    public static Object getObjectJsonRequestAuthentication(final String url, final String token) {
        try {
            HttpGet get = new HttpGet(url);
            get.setHeader("Content-Type", "application/json");
            get.setHeader("Authorization", "Bearer "+token);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(get);
            String strResponse = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            return JsonUtil.jsonToMap(strResponse);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    
    public static String getToken() {
        //Passar token atualizado.
        return "APP_USR-6080348676133328-062818-4305485d58c42f8ed12b8c3601eeee84-769168490";
    }
    
}
