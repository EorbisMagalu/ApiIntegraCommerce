package com.integracommerce.utilfreemarker;

import com.integracommerce.service.ParametrosRequisicao;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

public class ServiceUtil {

    public static Object getObjectJsonRequest(final String url) {
        try {
            HttpGet get = new HttpGet(url);
            get.setHeader("Content-Type", "application/json");
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(get);
            String strResponse = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            return JsonUtil.jsonToMap(strResponse);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    public static Object getObjectJsonRequestAuthentication(final String url, final String token) {
        try {
            HttpGet get = new HttpGet(url);
            get.setHeader("Content-Type", "application/json");
            get.setHeader("Authorization", "Bearer " + token);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(get);
            String strResponse = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            return JsonUtil.jsonToMap(strResponse);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    public String requestAnyHttp(ParametrosRequisicao pr) {

        List nameValuePairs = new ArrayList<>();
        for (Map.Entry<String, Object> par : pr.parametrosDaUrl().entrySet()) {
            nameValuePairs.add(new BasicNameValuePair(par.getKey(), par.getValue().toString()));
        }

        URI uri = null;
        try {
            uri = new URIBuilder(pr.url()).addParameters(nameValuePairs).build();
        } catch (URISyntaxException ex) {
            throw new RuntimeException(ex);
        }

        Map<String, Object> mapHttpRequest = getMapVerboHttp(uri);
        String contentRequest = "";
        for (Map.Entry<String, Object> entry : mapHttpRequest.entrySet()) {
            try {
                HttpRequestBase methodHttp = (HttpRequestBase) entry.getValue();
                setHeraderRequest(methodHttp, pr.header());
                HttpClient httpClient = HttpClients.createDefault();
                HttpResponse httpResponse = httpClient.execute(methodHttp);
                int statusCode = httpResponse.getStatusLine().getStatusCode();
                contentRequest = EntityUtils.toString(httpResponse.getEntity(), StandardCharsets.UTF_8);
                if (statusCode < 400) {
                    break;
                }
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }
        return contentRequest;
    }

    private static Map<String, Object> getMapVerboHttp(URI uri) {
        Map<String, Object> mapHttpRequest = new LinkedHashMap<>();
        mapHttpRequest.put("get", new HttpGet(uri));
        mapHttpRequest.put("post", new HttpPost(uri));
        mapHttpRequest.put("put", new HttpPut(uri));
        mapHttpRequest.put("delete", new HttpDelete(uri));
        return mapHttpRequest;
    }

    private static void setHeraderRequest(HttpRequestBase httpRequestBase, Map<String, String> mapHeaders) {
        for (Map.Entry<String, String> entry : mapHeaders.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            httpRequestBase.setHeader(key, value);
        }
    }

    public static String getToken() {
        //Passar token atualizado.
        return "APP_USR-6080348676133328-062818-4305485d58c42f8ed12b8c3601eeee84-769168490";
    }
}



//        ParametrosRequisicao parametrosRequisicao = new ParametrosRequisicao("https://api.mercadolibre.com/shipments/40663163620");
//        Map<String, String> header = new LinkedHashMap<>();
//        header.put("Authorization", "Bearer APP_USR-6080348676133328-062914-31cc5104045370ff77dec06b55319f08-769168490");
//        header.put("Content-Type", "application/json");
//        parametrosRequisicao.setHeader(header);
//        ServiceUtil serviceUtil = new ServiceUtil();
//        serviceUtil.requestAnyHttp(parametrosRequisicao);