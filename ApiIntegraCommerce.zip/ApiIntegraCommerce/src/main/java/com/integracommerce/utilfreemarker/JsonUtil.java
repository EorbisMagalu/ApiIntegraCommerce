package com.integracommerce.utilfreemarker;

import java.io.IOException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

public class JsonUtil {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    public static Object jsonToMap(String json) throws IOException {
        return OBJECT_MAPPER.readValue(json, new TypeReference<Object>() {});
    }
    
    public static String jsonToMap(Object obj) throws IOException {
        return OBJECT_MAPPER.writeValueAsString(obj);
    }
}
