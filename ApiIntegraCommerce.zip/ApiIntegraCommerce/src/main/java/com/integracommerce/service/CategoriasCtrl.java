package com.integracommerce.service;

import com.integracommerce.entidade.categoria.Categoria;
import com.integracommerce.entidade.categoria.Categorias;
import com.integracommerce.entidade.categoria.Filtros;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;

public class CategoriasCtrl {
    
    private String token;
    private CategoriasCtrl() {}

    public CategoriasCtrl(String token) {
        if(StringUtils.isBlank(token)) {
            throw new RuntimeException("Token não pode ser null, e nem vazio!");
        }
        this.token = token;
    }

    public void requestPost(String url,List<Categoria> categorias) {
        if (StringUtils.isBlank(url)) {
            url = "https://api.integracommerce.com.br/api/Category";
        }
        HttpPost post = new HttpPost(url);
        post.setHeader("cache-control", "no-cache");
        post.setHeader("Content-Type", "application/json");
        post.setHeader("authorization", "Basic "+this.token);
        try {
            String strCategoria = new ObjectMapper().writeValueAsString(categorias);
            StringEntity stringEntity = new StringEntity(strCategoria, ContentType.APPLICATION_JSON);
            post.setEntity(stringEntity);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(post);
            int statusCode = response.getStatusLine().getStatusCode();
            String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode+" "+response.getStatusLine().getReasonPhrase()+" "+responseBody);
            }
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

    }

    public Categorias requestGetAll(String url,Filtros filtros) {
        try {
            if(StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Category?";
            }
            HttpGet get = new HttpGet(url);
            get.setHeader("cache-control", "no-cache");
            get.setHeader("Content-Type", "application/json");
            get.setHeader("authorization", "Basic "+this.token);
            
            List nameValuePairs = new ArrayList<>();
            for (Map.Entry<String, Object> par : filtros.params().entrySet()) {
                nameValuePairs.add(new BasicNameValuePair(par.getKey(), par.getValue().toString()));
            }
            URI uri = new URIBuilder(get.getURI()).addParameters(nameValuePairs).build();
            get.setURI(uri);
            
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(get);
            
            int statusCode = response.getStatusLine().getStatusCode();
            String strResponse = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode+" "+response.getStatusLine().getReasonPhrase()+" "+strResponse);
            }
            
            ObjectMapper objectMapper = new ObjectMapper();
            Categorias categorias = objectMapper.readValue(strResponse, Categorias.class);
            return categorias;
        } catch (IOException | URISyntaxException ex) {
            throw new RuntimeException(ex);
        }
    }
    

    public Categoria requestGet(String url,String id) {
        try {
            if(StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Category/";
            }
            HttpGet get = new HttpGet(url + id);
            get.setHeader("cache-control", "no-cache");
            get.setHeader("Content-Type", "application/json");
            get.setHeader("authorization", "Basic "+this.token);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(get);
            
            int statusCode = response.getStatusLine().getStatusCode();
            String strResponse = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode+" "+response.getStatusLine().getReasonPhrase()+" "+strResponse);
            }
            
            ObjectMapper objectMapper = new ObjectMapper();
            Categoria categoria = objectMapper.readValue(strResponse, Categoria.class);
            return categoria;
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

}
