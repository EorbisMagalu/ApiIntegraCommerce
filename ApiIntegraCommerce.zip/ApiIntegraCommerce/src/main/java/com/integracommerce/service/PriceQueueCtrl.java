
package com.integracommerce.service;

import com.integracommerce.entidade.orderqueue.Queue;
import com.integracommerce.entidade.pricequeue.PriceQueue;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;

public class PriceQueueCtrl {
    
    public PriceQueue requestGet(String url) {
        try {
            if(StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/PriceQueue";
            }
            HttpGet get = new HttpGet(url);
            get.setHeader("cache-control", "no-cache");
            get.setHeader("Content-Type", "application/json");
            get.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");

            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(get);
            int statusCode = response.getStatusLine().getStatusCode();
            String strResponse = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + strResponse);
            }
            ObjectMapper objectMapper = new ObjectMapper();
            PriceQueue priceQueue = objectMapper.readValue(strResponse, PriceQueue.class);
            return priceQueue;
            
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        
    }
    
    public void requestPut(String url, Queue[] ids) {
        try {
            if(StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/OrderQueue";
            }
            HttpPut put = new HttpPut(url);
            put.setHeader("cache-control", "no-cache");
            put.setHeader("Content-Type", "application/json");
            put.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");
            String strArrayids = new ObjectMapper().writeValueAsString(ids);
            StringEntity stringEntity = new StringEntity(strArrayids, ContentType.APPLICATION_JSON);
            put.setEntity(stringEntity);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(put);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode >= 400) {
                String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + responseBody);
            }
            
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    
}
