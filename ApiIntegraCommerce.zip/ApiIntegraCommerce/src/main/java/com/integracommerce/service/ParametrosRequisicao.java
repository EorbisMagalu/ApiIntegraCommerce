
package com.integracommerce.service;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 *
 * @author metaprime
 */
public class ParametrosRequisicao {

    private String url;
    private Map<String,Object> parametrosDaUrl;
    private Map<String,String> header;
    private String body;
    
    public ParametrosRequisicao(String url) {
        this.url = url;
    }

    public Map<String, Object> getParametrosDaUrl() {
        return parametrosDaUrl;
    }

    public void setParametrosDaUrl(Map<String, Object> parametrosDaUrl) {
        this.parametrosDaUrl = parametrosDaUrl;
    }

    public void setParametrosUrl(Map<String,Object> paramsUrl) {
        this.parametrosDaUrl = paramsUrl;
    }
    
    public Map<String,Object> parametrosDaUrl() {
        if(this.parametrosDaUrl == null) return new LinkedHashMap<>();
        return this.parametrosDaUrl;
    }

    public Map<String, String> header() {
        if(this.header == null) return new LinkedHashMap<>();
        return header;
    }

    public void setHeader(Map<String, String> header) {
        this.header = header;
    }

    public String url() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String body() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }
    
    
    
}

