
package com.integracommerce.ctrl;

import com.integracommerce.entidade.skuqueue.SkuQueue;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;

public class SkuQueueCtrl {
    
    public SkuQueue requestGetAll(String url) {
        try {
            if(StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/SkuQueue";
            }
            HttpGet get = new HttpGet(url);
            get.setHeader("cache-control", "no-cache");
            get.setHeader("Content-Type", "application/json");
            get.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(get);
            int statusCode = response.getStatusLine().getStatusCode();
            String strResponse = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + strResponse);
            }
            ObjectMapper objectMapper = new ObjectMapper();
            SkuQueue queue = objectMapper.readValue(strResponse, SkuQueue.class);
            return queue;
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
}
