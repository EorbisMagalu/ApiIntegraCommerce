
package com.integracommerce.ctrl;

import com.integracommerce.entidade.invoice.Invoice;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;

public class InvoiceCtrl {
    
    public void requestPut(String url,String id, Invoice invoice) {
        
        try {
            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/v1/invoice/";
            }
            if(StringUtils.isBlank(id)) {
                id = "1228";
            }
            HttpPut put = new HttpPut(url + id);
            put.setHeader("cache-control", "no-cache");
            put.setHeader("Content-Type", "application/json");
            put.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");

            String strInvoice = new ObjectMapper().writeValueAsString(invoice);
            StringEntity stringEntity = new StringEntity(strInvoice, ContentType.APPLICATION_JSON);
            put.setEntity(stringEntity);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(put);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode >= 400) {
                String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + responseBody);
            }
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
}
//ctrl.requestPut(null, null, new Invoice("852", "4141744", "475275", "2021-06-14"));