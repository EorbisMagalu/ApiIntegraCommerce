package com.integracommerce.ctrl;

import com.integracommerce.entidade.sku.Sku;
import com.integracommerce.entidade.sku.Skus;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;

public class SkuCtrl {
    
    private String token;
    private SkuCtrl() {}

    public SkuCtrl(String token) {
        if(StringUtils.isBlank(token)) {
            throw new RuntimeException("Token não pode ser null, e nem vazio!");
        }
        this.token = token;
    }
    
    public void requestPost(String url, Sku sku) {
        try {
            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Sku";
            }
            HttpPost post = new HttpPost(url);
            post.setHeader("cache-control", "no-cache");
            post.setHeader("Content-Type", "application/json");
            post.setHeader("authorization", "Basic "+this.token);
            String strSku = new ObjectMapper().writeValueAsString(sku);
            StringEntity stringEntity = new StringEntity(strSku, ContentType.APPLICATION_JSON);
            post.setEntity(stringEntity);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(post);
            int statusCode = response.getStatusLine().getStatusCode();
            String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + responseBody);
            }
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    public Skus requestGetAll(String url, String strPagePerPage) {
        try {
            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Sku?";
            }
            if (StringUtils.isBlank(strPagePerPage)) {
                strPagePerPage = "page=1&perPage=100";
            }

            HttpGet get = new HttpGet(url + strPagePerPage);
            get.setHeader("cache-control", "no-cache");
            get.setHeader("Content-Type", "application/json");
            get.setHeader("authorization", "Basic "+this.token);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(get);

            int statusCode = response.getStatusLine().getStatusCode();
            String strResponse = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + strResponse);
            }

            ObjectMapper objectMapper = new ObjectMapper();
            Skus skus = objectMapper.readValue(strResponse, Skus.class);
            return skus;

        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    public Sku requestGet(String url, String id) {
        try {
            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Sku/";
            }
            if (StringUtils.isBlank(id)) {
                id = "111";
            }

            HttpGet get = new HttpGet(url + id);
            get.setHeader("cache-control", "no-cache");
            get.setHeader("Content-Type", "application/json");
            get.setHeader("authorization", "Basic "+this.token);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(get);

            int statusCode = response.getStatusLine().getStatusCode();
            String strResponse = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + strResponse);
            }

            ObjectMapper objectMapper = new ObjectMapper();
            Sku skus = objectMapper.readValue(strResponse, Sku.class);
            return skus;
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    public void requestPut(String url, Sku sku) {
        try {
            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Sku";
            }
            HttpPut put = new HttpPut(url);
            put.setHeader("cache-control", "no-cache");
            put.setHeader("Content-Type", "application/json");
            put.setHeader("authorization", "Basic "+this.token);

            String strSku = new ObjectMapper().writeValueAsString(sku);
            StringEntity stringEntity = new StringEntity(strSku, ContentType.APPLICATION_JSON);
            put.setEntity(stringEntity);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(put);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode >= 400) {
                String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + responseBody);
            }
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
}

//Sku sku = new Sku();
//sku.setIdSku("111");
//sku.setIdSkuErp("1111");
//sku.setIdProduct("5555");
//sku.setName("SKU Teste 01");
//sku.setDescription("Primeiro teste sku");
//sku.setHeight(5);
//sku.setWidth(6);
//sku.setLength(1);
//sku.setWeight(2);
//sku.setCodeEan("123");
//sku.setCodeNcm("321");
//sku.setCodeIsbn("745");
//sku.setCodeNbm("85");
//sku.setVariation("Variação");
//sku.setStatus(true);
//Price price = new Price();
//price.setListPrice(new BigDecimal("10"));
//price.setSalePrice(new BigDecimal("1"));
//sku.setPrice(price);
//sku.setStockQuantity(10);
//sku.setMainImageUrl("http://thumbs2.imgbox.com/41/8e/otZZ4ja9_t.png");
//List<String> imgs = new ArrayList<>();
//imgs.add("http://thumbs2.imgbox.com/41/8e/otZZ4ja9_t.png");
//sku.setUrlImages(imgs);
//SkuCtrl ctrl = new SkuCtrl();
//ctrl.requestPost("", sku);

