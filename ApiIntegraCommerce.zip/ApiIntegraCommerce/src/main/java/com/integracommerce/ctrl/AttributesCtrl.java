
package com.integracommerce.ctrl;

import com.integracommerce.entidade.atributos.Attributes;
import com.integracommerce.entidade.atributos.Filtros;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;

public class AttributesCtrl {
    
    private String token;
    private AttributesCtrl() {}

    public AttributesCtrl(String token) {
        if(StringUtils.isBlank(token)) {
            throw new RuntimeException("Token não pode ser null, e nem vazio!");
        }
        this.token = token;
    }
    
    public Attributes requestGet(String url,Filtros filtros) {
        try {
            if(StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Attribute?";
            }

            HttpGet get = new HttpGet(url);
            get.setHeader("cache-control", "no-cache");
            get.setHeader("Content-Type", "application/json");
            get.setHeader("authorization", "Basic "+this.token);
            
            List nameValuePairs = new ArrayList<>();
            for (Map.Entry<String, Object> par : filtros.params().entrySet()) {
                nameValuePairs.add(new BasicNameValuePair(par.getKey(), par.getValue().toString()));
            }
            URI uri = new URIBuilder(get.getURI()).addParameters(nameValuePairs).build();
            get.setURI(uri);
            
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(get);
            
            int statusCode = response.getStatusLine().getStatusCode();
            String strResponse = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode+" "+response.getStatusLine().getReasonPhrase()+" "+strResponse);
            }
            
            ObjectMapper objectMapper = new ObjectMapper();
            Attributes attributes = objectMapper.readValue(strResponse, Attributes.class);
            return attributes;
        } catch (IOException | URISyntaxException ex) {
            throw new RuntimeException(ex);
        }
    }
}
