package com.integracommerce.ctrl;

import com.integracommerce.entidade.promotion.Filtros;
import com.integracommerce.entidade.promotion.Promotion;
import com.integracommerce.entidade.promotion.Promotions;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;

public class PromotionCtrl {

    public void requestPost(String url, List<Promotion> promotions) {
        try {

            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Promotion";
            }

            HttpPost post = new HttpPost(url);
            post.setHeader("cache-control", "no-cache");
            post.setHeader("Content-Type", "application/json");
            post.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");

            String strPromotion = new ObjectMapper().writeValueAsString(promotions);
            StringEntity stringEntity = new StringEntity(strPromotion, ContentType.APPLICATION_JSON);
            post.setEntity(stringEntity);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(post);
            int statusCode = response.getStatusLine().getStatusCode();
            String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + responseBody);
            }

        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    public Promotions requestGet(String url, String id) {
        try {
            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Promotion/";
            }
            if (StringUtils.isBlank(id)) {
                id = "1";
            }

            HttpGet get = new HttpGet(url + id);
            get.setHeader("cache-control", "no-cache");
            get.setHeader("Content-Type", "application/json");
            get.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");

            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(get);
            int statusCode = response.getStatusLine().getStatusCode();
            String strResponse = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + strResponse);
            }
            ObjectMapper objectMapper = new ObjectMapper();
            Promotions promotions = objectMapper.readValue(strResponse, Promotions.class);
            return promotions;

        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    public Promotions requestGetAll(String url, Filtros filtros) {
        try {
            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Promotion?";
            }
            HttpGet get = new HttpGet(url);
            get.setHeader("cache-control", "no-cache");
            get.setHeader("Content-Type", "application/json");
            get.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");

            List nameValuePairs = new ArrayList<>();
            for (Map.Entry<String, Object> par : filtros.params().entrySet()) {
                nameValuePairs.add(new BasicNameValuePair(par.getKey(), par.getValue().toString()));
            }
            URI uri = new URIBuilder(get.getURI()).addParameters(nameValuePairs).build();
            get.setURI(uri);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(get);
            int statusCode = response.getStatusLine().getStatusCode();
            String strResponse = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + strResponse);
            }
            ObjectMapper objectMapper = new ObjectMapper();
            Promotions promotions = objectMapper.readValue(strResponse, Promotions.class);
            return promotions;
        } catch (IOException | URISyntaxException ex) {
            throw new RuntimeException(ex);
        }

    }

    public void requestDelete(String url, String id) {

        try {
            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Promotion/";
            }

            if (StringUtils.isBlank(id)) {
                id = "1";
            }

            HttpDelete httpDelete = new HttpDelete(url + id);
            httpDelete.setHeader("cache-control", "no-cache");
            httpDelete.setHeader("Content-Type", "application/json");
            httpDelete.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(httpDelete);

            int statusCode = response.getStatusLine().getStatusCode();
            String strResponse = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + strResponse);
            }

        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

    }

    public void requestPost(String url, String id) {

        try {

            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Promotion/Signup/";
            }

            if (StringUtils.isBlank(id)) {
                id = "1";
            }

            HttpPost post = new HttpPost(url + id);
            post.setHeader("cache-control", "no-cache");
            post.setHeader("Content-Type", "application/json");
            post.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");

            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(post);
            int statusCode = response.getStatusLine().getStatusCode();
            String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + responseBody);
            }

        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

    }

    public void requestPut(String url, String id) {
        try {

            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Promotion/";
            }

            if (StringUtils.isBlank(id)) {
                id = "1";
            }

            HttpPut put = new HttpPut(url + id);
            put.setHeader("cache-control", "no-cache");
            put.setHeader("Content-Type", "application/json");
            put.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");

            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(put);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode >= 400) {
                String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + responseBody);
            }

        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

    }

}

//Promotion promotion = new Promotion();
//promotion.setIdSku("111");
//promotion.setListPrice(new BigDecimal("150"));
//promotion.setSalePrice(new BigDecimal("5"));
//LocalDateTime today = LocalDateTime.now();
//LocalDateTime tomorrow = today.plusDays(2);
//DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
//promotion.setStartDate(formatter.format(today));
//promotion.setEndDate(formatter.format(tomorrow));
//List<Promotion> promotions = new ArrayList<>();
//promotions.add(promotion);
//
//new PromotionCtrl().requestPost("", promotions);
