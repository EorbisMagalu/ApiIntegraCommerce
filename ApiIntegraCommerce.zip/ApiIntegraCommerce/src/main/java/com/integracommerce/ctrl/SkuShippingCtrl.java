package com.integracommerce.ctrl;

import com.integracommerce.entidade.skushipping.SkuShipping;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;

public class SkuShippingCtrl {

    public void requestPost(String url, SkuShipping skuShipping) {

        try {

            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/skuShipping/Create";
            }

            HttpPost post = new HttpPost(url);
            post.setHeader("cache-control", "no-cache");
            post.setHeader("Content-Type", "application/json");
            post.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");

            String srtskuShipping = new ObjectMapper().writeValueAsString(skuShipping);
            StringEntity stringEntity = new StringEntity(srtskuShipping, ContentType.APPLICATION_JSON);
            post.setEntity(stringEntity);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(post);
            int statusCode = response.getStatusLine().getStatusCode();
            String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + responseBody);
            }

        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    public void requestDelete(String url, String id) {
        try {
            
            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/skuShipping/";
            }
            if (StringUtils.isBlank(id)) {
                id = "111";
            }
            
            HttpDelete httpDelete = new HttpDelete(url+id);
            httpDelete.setHeader("cache-control", "no-cache");
            httpDelete.setHeader("Content-Type", "application/json");
            httpDelete.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(httpDelete);
            
            int statusCode = response.getStatusLine().getStatusCode();
            String strResponse = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + strResponse);
            }
            
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
}
