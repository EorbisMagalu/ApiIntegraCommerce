
package com.integracommerce.ctrl;

import com.integracommerce.entidade.sku.Price;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;

public class PriceCtrl {
    
    public void requestPut(String url, List<Price> prices) {
        
        try {
            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Price";
            }

            HttpPut put = new HttpPut(url);
            put.setHeader("cache-control", "no-cache");
            put.setHeader("Content-Type", "application/json");
            put.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");

            String srtProduto = new ObjectMapper().writeValueAsString(prices);
            StringEntity stringEntity = new StringEntity(srtProduto, ContentType.APPLICATION_JSON);
            put.setEntity(stringEntity);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(put);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode >= 400) {
                String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + responseBody);
            }
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        
    }
    
    
}
