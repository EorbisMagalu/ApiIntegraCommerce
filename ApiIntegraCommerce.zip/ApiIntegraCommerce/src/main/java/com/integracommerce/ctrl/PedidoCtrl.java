package com.integracommerce.ctrl;

import com.integracommerce.entidade.orderqueue.Queue;
import com.integracommerce.entidade.pedido.Filtros;
import com.integracommerce.entidade.pedido.ParametrosImpressao;
import com.integracommerce.entidade.pedido.Pedido;
import com.integracommerce.entidade.pedido.Pedidos;
import com.integracommerce.entidade.pedido.ShippingLabels;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;

public class PedidoCtrl {

    public void requestPost(String url, Pedido pedido) {
        try {
            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Order";
            }
            HttpPost post = new HttpPost(url);
            post.setHeader("cache-control", "no-cache");
            post.setHeader("Content-Type", "application/json");
            post.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");
            String strPedido = new ObjectMapper().writeValueAsString(pedido);
            StringEntity stringEntity = new StringEntity(strPedido, ContentType.APPLICATION_JSON);
            post.setEntity(stringEntity);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(post);
            int statusCode = response.getStatusLine().getStatusCode();
            String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + responseBody);
            }
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    public void requestPut(String url, Pedido pedido) {
        try {
            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Order";
            }
            HttpPut put = new HttpPut(url);
            put.setHeader("cache-control", "no-cache");
            put.setHeader("Content-Type", "application/json");
            put.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");

            String strPedido = new ObjectMapper().writeValueAsString(pedido);
            StringEntity stringEntity = new StringEntity(strPedido, ContentType.APPLICATION_JSON);
            put.setEntity(stringEntity);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(put);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode >= 400) {
                String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + responseBody);
            }
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    public Pedidos requestGetAll(String url, Filtros filtros) {

        try {
            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Order?";
            }
            HttpGet get = new HttpGet(url);
            get.setHeader("cache-control", "no-cache");
            get.setHeader("Content-Type", "application/json");
            get.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");

            List nameValuePairs = new ArrayList<>();
            for (Map.Entry<String, Object> par : filtros.params().entrySet()) {
                nameValuePairs.add(new BasicNameValuePair(par.getKey(), par.getValue().toString()));
            }
            URI uri = new URIBuilder(get.getURI()).addParameters(nameValuePairs).build();
            get.setURI(uri);

            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(get);
            int statusCode = response.getStatusLine().getStatusCode();
            String strResponse = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + strResponse);
            }
            ObjectMapper objectMapper = new ObjectMapper();
            Pedidos pedidos = objectMapper.readValue(strResponse, Pedidos.class);
            return pedidos;

        } catch (IOException | URISyntaxException ex) {
            throw new RuntimeException(ex);
        }
    }

    public Pedido requestGet(String url, String id) {
        try {
            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Order/";
            }
            if (StringUtils.isBlank(id)) {
                id = "1";
            }

            HttpGet get = new HttpGet(url + id);
            get.setHeader("cache-control", "no-cache");
            get.setHeader("Content-Type", "application/json");
            get.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");

            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(get);
            int statusCode = response.getStatusLine().getStatusCode();
            String strResponse = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + strResponse);
            }
            ObjectMapper objectMapper = new ObjectMapper();
            Pedido pedido = objectMapper.readValue(strResponse, Pedido.class);
            return pedido;

        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    public ShippingLabels requestPost(String url, ParametrosImpressao parametrosImpressao) {

        try {
            if (StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Order/ShippingLabels";
            }
            HttpPost post = new HttpPost(url);
            post.setHeader("cache-control", "no-cache");
            post.setHeader("Content-Type", "application/json");
            post.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");
            String strParametrosImpressao = new ObjectMapper().writeValueAsString(parametrosImpressao);
            StringEntity stringEntity = new StringEntity(strParametrosImpressao, ContentType.APPLICATION_JSON);
            post.setEntity(stringEntity);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(post);
            int statusCode = response.getStatusLine().getStatusCode();
            String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            if (statusCode >= 400) {
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + responseBody);
            }
            ObjectMapper objectMapper = new ObjectMapper();
            ShippingLabels shippingLabels = objectMapper.readValue(responseBody, ShippingLabels.class);
            return shippingLabels;
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    public void requestPost(String url, Queue[] queue) {
        try {
            if(StringUtils.isBlank(url)) {
                url = "https://api.integracommerce.com.br/api/Order/ConfirmReserves";
            }
            HttpPost post = new HttpPost(url);
            post.setHeader("cache-control", "no-cache");
            post.setHeader("Content-Type", "application/json");
            post.setHeader("authorization", "Basic b3Bwb3J0dW5pdHlwYXJ0c2FwaTpMMEFNWlhrVEJXbXByUGlCaTZETg==");

            String strQueue = new ObjectMapper().writeValueAsString(queue);
            StringEntity stringEntity = new StringEntity(strQueue, ContentType.APPLICATION_JSON);
            post.setEntity(stringEntity);
            HttpClient httpClient = HttpClients.createDefault();
            HttpResponse response = httpClient.execute(post);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode >= 400) {
                String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                throw new RuntimeException(statusCode + " " + response.getStatusLine().getReasonPhrase() + " " + responseBody);
            }
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

}

//MarketplaceCtrl marketplaceCtrl = new MarketplaceCtrl();
//String nomeMarket = marketplaceCtrl.requestGetAll("").getMarketplaces().stream().filter(market -> market.getName().contains("maga")).findFirst().get().getName();
//
//PedidoCtrl ctrl = new PedidoCtrl();
//System.out.println(nomeMarket);
//Pedido pedido = new Pedido();
//pedido.setIdOrder("1228");
//pedido.setIdOrderMarketplace("02-622032732");
//pedido.setInsertedDate("14-06-2021");
//pedido.setPurchasedDate("14-06-2021");
//pedido.setApprovedDate("14-06-2021");
//pedido.setMarketplaceName(nomeMarket);
//pedido.setStoreName("Amilkar");
//pedido.setUpdatedMarketplaceStatus(true);
//pedido.setInsertedErp(true);
//pedido.setEstimatedDeliveryDate("14-06-2021");
//pedido.setCustomerPfCpf("04222746150");
//pedido.setReceiverName("Joaquim da hora");
//pedido.setCustomerPfName("SUD");
//pedido.setCustomerPjCnpj("22319933000189");
//pedido.setCustomerPjCorporatename("SUD TEC");
//pedido.setDeliveryAddressStreet("Rua SUD");
//pedido.setDeliveryAddressAdditionalInfo("Perto do bordel");
//pedido.setDeliveryAddressZipcode("75060-210");
//pedido.setDeliveryAddressNeighborhood("Bairro SUD");
//pedido.setDeliveryAddressCity("Cidade SUD");
//pedido.setTotalAmount("120");
//pedido.setTotalTax("10");
//pedido.setTotalFreight("15");
//pedido.setTotalDiscount("5");
//pedido.setCustomerMail("sud@dus.com.eua");
//pedido.setCustomerBirthDate("14-06-1998");
//pedido.setCustomerPjIe("5");
//pedido.setOrderStatus(StatusPedido.NEW);
//pedido.setInvoicedNumber("654887848945222");
//pedido.setInvoicedLine(777);
//pedido.setInvoicedIssueDate("14-06-2021");
//pedido.setInvoicedKey("1");
//pedido.setInvoicedDanfeXml("");
//pedido.setShippedTrackingUrl("bing.com");
//pedido.setShippedTrackingProtocol("31654");
//pedido.setShippedEstimatedDelivery("14-06-2021");
//pedido.setShippedCarrierDate("14-06-2021");
//pedido.setShippedCarrierName("Flash");
//pedido.setShipmentExceptionObservation("Entregar aos cuidado do fulana");
//pedido.setShipmentExceptionOccurrenceDate("14-06-2021");
//pedido.setDeliveredDate("14-06-2021");
//pedido.setShippedCodeERP("101");
//pedido.setBranchDocument("689856");
//pedido.setMarketplaceDocument("8");
//pedido.setSellerName("Amilkar");
//pedido.setGatewayPaymentDocument("515");
//
//Products product = new Products();
//List<Products> Products = new ArrayList<>();
//product.setDiscount("10");
//product.setFreight("1");
//product.setIdOrderPackage(1);
//product.setIdSku("111");
//product.setPrice("100");
//product.setQuantity(10);
//Products.add(product);
//
//List<Payments> Payments = new ArrayList<>();
//Payments paya = new Payments();
//paya.setAmount(new BigDecimal("14"));
//paya.setInstallments(1);
//paya.setName(TipoPagamento.DEBIT_CARD.getValue());
//Payments.add(paya);
//
//pedido.setProducts(Products);
//pedido.setPayments(Payments);
//
//ctrl.requestPost("", pedido);
